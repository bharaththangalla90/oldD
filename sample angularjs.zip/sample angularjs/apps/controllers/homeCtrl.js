(function() {
    'use strict';

    fileuploader.controller("homeCtrl", ['$scope', '$rootScope' ,'uiRouters', '$location', '$route', '$window', homeCtrl]);

    function homeCtrl($scope, $rootScope, uiRouters, $location, $route, $window) {

        $scope.message = "";
        $scope.emitedmessage = "";
        $scope.clickevent = function() {
            if($scope.message.length <= 0){
                alert("please enter");
            }
            else{
                $scope.$emit('transfer', { message: $scope.message });
                $location.url(uiRouters.dashboard);
                $rootScope.message = $scope.message;
            }
            
        }
        $scope.$on('transferUp', function(event, data) {
            $scope.emitedmessage = data.message;
        });

    }

})();
