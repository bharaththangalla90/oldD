(function() {
    'use strict';

    fileuploader.controller("dashboardCtrl", ['$scope', '$rootScope', 'uiRouters', '$location', dashboardCtrl]);

    function dashboardCtrl($scope, $rootScope, uiRouters, $location) {

        $scope.message = "";
        $scope.broadcastmessage = ""
        $scope.broadcastmessage = $rootScope.message;
        $scope.$on('transfer', function(event, data) {
            $scope.broadcastmessage = data.message;
            $scope.message = $rootScope.message;
        });

        $scope.navigatToHome = function() {
            $location.url(uiRouters.home);
        }

    }

})();
