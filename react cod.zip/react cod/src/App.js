import './styles/App.css';
import './styles/theme-gentella.css';

import React, { Component } from 'react';
import { Layout, Menu, Icon, notification } from 'antd';
import { Row, Col } from 'antd';
import moment from 'moment'
import {Icon as FAIcon } from 'react-fa';
import { Avatar } from 'antd';
import { Dropdown } from 'antd';
import { Badge, Popover, Modal } from 'antd';
import { Affix } from 'antd';
import Block from 'react-blocks';
import { LocaleProvider } from 'antd';
import enUS from 'antd/lib/locale-provider/en_US';
import { Table } from 'antd';
import AlertsTable from './notifications/AlertsTable';
import {
  HashRouter as Router,
  Route,
  Link,
  Switch
} from 'react-router-dom';
import Dashboard from './dashboard/Dashboard'
import ClinicSites from './clinic_status/ClinicSites'
import Provisioning from './provisioning/Provisioning'
import Policies from './policies/Policies'
import Inventory from './monitoring/inventory'
import Settings from './settings/Settings'
import Users from './users/Users'
//import io from 'socket.io-client';

//const socket = io.connect('http://10.195.77.53:8087'); //Real time notification disabled for now

const { Content, Footer, Sider } = Layout;
const SubMenu = Menu.SubMenu;

const menu = (
  <Menu>
    <Menu.Item>
      <a target="_blank" rel="noopener noreferrer">Profile</a>
    </Menu.Item>
    <Menu.Item>
      <a target="_blank" rel="noopener noreferrer">Settings</a>
    </Menu.Item>
    <Menu.Item>
      <a target="_blank" rel="noopener noreferrer" href="http://10.195.77.53:5000/logout">Logout</a>
    </Menu.Item>
  </Menu>
);


class App extends Component {
  state = {
    collapsed: false,
    mode: 'inline',
    clinicNetworkData: [],
    systemHealth: [],
    clinicStatusData:[],
    securityDetails: [],
    networkClients: [],
    currentPage:'dashboard',
    modalVisible: false,
    visible: false,
    dataReady: false,
    activeAlerts: [],
    alerts: []
  };

  openNotification = (category, message) => {
    notification.open({
      message: 'Notification:'+category,
      description: message,
    });
  };

  pollActiveAlerts() {
    const urls = ['http://10.195.77.27:5000/meraki_events', 'http://10.195.77.53:5000/cloudlock_incidents'];

    Promise.all(urls.map(url => fetch(url)))
    .then(responses =>
      Promise.all(responses.map(res => res.json())))
      .then(jsons => {
        const merakiData = jsons[0].filter(item => item['data'][0].Severity !== "").reverse()
        const cloudLockData = jsons[1]["alerts"].filter(item => item.severity !== "" && moment(moment(item.Created_At).format('MMM DD hh:mm:ss')).isAfter(moment().subtract(5, 'days').format('MMM DD 00:00:00'))).reverse()

        const merakiProcessedData = merakiData.map((item, index) => { return {Time: moment(item['data'][0].Time).format('MMM DD hh:mm:ss'), Item:item['data'][0].Event_type, Category: item['data'][0].Category, Details: item['data'][0].Details, Status:item['data'][0].Severity, Action: 'Review'}})
        const cloudLockProcessedData = cloudLockData.map((item, index) => {return {Time: moment(item.Created_At).format('MMM DD hh:mm:ss'), Category: "CloudLock", Item: item.policy_name, name: item.owner_Name, email: item.owner_email, Status: (item.severity === "INFO") ? "Info" : item.severity, Action: "Review"}})

        const merakiActiveAlerts = merakiProcessedData.filter(item => moment(item.Time).isAfter(moment(this.state.merakiLatestLogTime)))
        const clouldLockActiveAlerts = cloudLockProcessedData.filter(item => moment(item.Time).isAfter(moment(this.state.cloudLockLatestLogTime)))

        const eventLogData = [...merakiProcessedData, ...cloudLockProcessedData]
        const activeAlerts = [...merakiActiveAlerts, ...clouldLockActiveAlerts]
        this.setState({activeAlerts:activeAlerts, alerts:eventLogData, dataReady: true, merakiLatestLogTime: merakiProcessedData.length > 0 ? merakiProcessedData[0].Time : "", cloudLockLatestLogTime: cloudLockProcessedData.length > 0 ? cloudLockProcessedData[0].Time :"" })
      })
  }

  showModal = () => {
    this.setState({
      modalVisible: true,
    });
  }

  handleOk = (e) => {
    //console.log(e);
    this.setState({
      modalVisible: false,
    });
  }

  handleCancel = (e) => {
    //console.log(e);
    this.setState({
      modalVisible: false,
    });
  }

  onCollapse = (collapsed) => {
    //console.log(collapsed);
    this.setState({
      collapsed,
      mode: collapsed ? 'vertical' : 'inline',
    }, ()=> this.scrollToTop());
  }

  toggleCollapse = () => {
    this.setState({collapsed: !this.state.collapsed}, () => this.onCollapse(this.state.collapsed));
  }

  componentWillMount() {

    this.pollActiveAlerts()

    window.addEventListener("resize", this.scrollToTop);
    //the code below is commented to disable websocket notifications temporarily
    /*socket.on('connect', () => {socket.emit('connection', {data: 'I\'m connected!'});console.log('Connected to socket server')});
    socket.on('notification', data =>
      {
        this.openNotification(data.category, data.message);
        let newAlerts = this.state.alerts.slice()
        newAlerts.push({key:this.state.alerts.length, timestamp:moment().format(), item: data.item || 'General', action: data.action || 'Review' , severity:data.category, description:data.message })
        this.setState({alerts: newAlerts})
      });*/
  }

  componentDidMount() {
    //this.loadInterval = setInterval(this.pollActiveAlerts.bind(this), 30000);
  }

  componentWillUnmount () {
    this.loadInterval && clearInterval(this.loadInterval);
  }

  scrollToTop = (s) => { document.getElementById("content-pane").scrollTop = 0; }

  render() {

    return (
      <Router>
      <LocaleProvider locale={enUS}>
      <Layout style={{height:"100vh"}}>
        <Sider
          collapsible
          collapsed={this.state.collapsed}
          onCollapse={this.onCollapse}
          width={230}
          className="sidebar"
          trigger={null}
          breakpoint="lg"
        >
        <div className="logo" style={{color:"#fff", paddingTop:"0.5em", paddingBottom:"1em", textAlign:"center"}} >
        { this.state.collapsed ?
          <h2 className="title-font" style={{paddingTop:"0.42em"}}> <img alt="logo" src="Cisco_logo.svg" height={25} /><img alt="logo" src="optum-logo-white-cropped.png" height={15} /></h2>
          :
          <h2 className="title-font" style={{paddingTop:"0.42em"}}> <img alt="logo" src="Cisco_logo.svg" height={30} /> <img alt="logo" src="optum-logo-white-cropped.png" height={30} /></h2>
        }
        </div>
        { !this.state.collapsed ?
        <Row>
        <br />
        <Col span={6} offset={3}>
          <Avatar size="large" icon="user" className="bordered-icon"/>
        </Col>
        <Col span={11} offset={2}>
          <div style={{color:"#BAB8B8", paddingTop:"0.5em"}}>Welcome,</div><div style={{color:"#fff"}}> Zhiang</div>
        </Col>
        <br />
        </Row>
        : ""
      }
          <br />
          <Menu mode={this.state.mode} defaultSelectedKeys={['1']} >
            <Menu.Item key="1" className="sidebar-item" >
            <Link to="/dashboard">
              <Icon type="line-chart" />
              <span className="nav-text">Dashboard</span>
            </Link>
            </Menu.Item>

            <SubMenu className="sidebar-item"
              key="sub2"
              title={<span><Icon type="appstore-o" /><span className="nav-text">Services</span></span>}
            >
              <Menu.Item key="4" className="sidebar-item"><a className="sidebar-link" href="https://10.195.77.35:9031/idp/startSSO.ping?PartnerSpId=n180.meraki.com"><span className="sidebar-link">Networking</span></a></Menu.Item>
              <Menu.Item key="51" className="sidebar-item"><a className="sidebar-link" ><span className="sidebar-link">Internet</span></a></Menu.Item>
              <Menu.Item key="61" className="sidebar-item"><a className="sidebar-link" ><span className="sidebar-link">Mobile Devices</span></a></Menu.Item>
              <Menu.Item key="5" className="sidebar-item"><a className="sidebar-link" href="https://10.195.77.20/admin/login.jsp"><span className="sidebar-link">Users</span></a></Menu.Item>
              <SubMenu className="sidebar-item"
                key="sub3"
                title={<span><span className="nav-text">Cyber Security</span></span>}
              >
                <Menu.Item key="6" className="sidebar-item"><a className="sidebar-link" href="https://10.195.77.35:9031/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Flogin.umbrella.com%2Fsso"><span className="sidebar-link">Umbrella</span></a></Menu.Item>
                <Menu.Item key="7" className="sidebar-item">
                <a className="sidebar-link" href="https://ciscosolman.cloudlockng.com"><span className="sidebar-link">CloudLock</span></a>
                </Menu.Item>
              </SubMenu>
              <Menu.Item key="8" className="sidebar-item"><a className="sidebar-link" href="https://10.195.77.35:9031/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fidbroker.webex.com%2Fa8bc4519-cd45-4ed8-b393-164231bf2b4c"><span className="sidebar-link">Communication</span></a></Menu.Item>
              <Menu.Item key="9" className="sidebar-item"><a className="sidebar-link" href="http://10.195.77.27/CiscoHealthCare/index.html"><span className="sidebar-link">Clinical Data</span></a></Menu.Item>
              <Menu.Item key="71" className="sidebar-item"><a className="sidebar-link" href="https://eprescribe.allscripts.com/Login.aspx?ReturnUrl=%2f"><span className="sidebar-link">Clinical Applications</span></a></Menu.Item>
            </SubMenu>
            <Menu.Item key="10" className="sidebar-item">
              <Link to="/clinicsites">
                <Icon type="medicine-box" />
                <span className="nav-text">Clinic Sites</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="12" className="sidebar-item">
              <Link to="/provisioning">
                <Icon type="database" />
                <span className="nav-text">Provisioning</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="13" className="sidebar-item">
            <a className="sidebar-link" target="_blank" rel="noopener noreferrer" href="https://apps.cisco.com/Commerce/guest">
              <span>
                <Icon type="credit-card" />
                <span className="nav-text">Ordering</span>
              </span>
            </a>
            </Menu.Item>
            <Menu.Item key="18" className="sidebar-item">
              <Link to="/users">
                <Icon type="team" />
                <span className="nav-text">Users</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="16" className="sidebar-item">
              <Link to="/policy">
                <Icon type="environment-o" />
                <span className="nav-text">Policies</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="19" className="sidebar-item">
              <Link to="/inventory">
                <Icon type="folder-open" />
                <span className="nav-text">Inventory</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="14" className="sidebar-item">
              <Link to="/settings">
                <Icon type="setting" />
                <span className="nav-text">Settings</span>
              </Link>
            </Menu.Item>
            <Menu.Item key="15" className="sidebar-item">
            <a className="sidebar-link" href="http://10.195.77.53:5000/logout">
              <span>
                <Icon type="logout" />
                <span className="nav-text">Logout</span>
              </span>
            </a>
            </Menu.Item>
          </Menu>
        </Sider>
        <Layout className="content" id="content-pane">
        <Modal
          width={800}
          title="Alerts"
          visible={this.state.modalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
        <AlertsTable dataReady={this.state.dataReady} data={this.state.alerts} />
        </Modal>
          <Content style={{ margin: '0 16px' }}>
          <Affix target={() => document.getElementById("content-pane")} style={{width:"100%"}}>
          <div style={{marginRight:"-1.15em", marginLeft:"-1.15em", background: '#EDEDED', paddingLeft:"1em", borderBottom: "1px solid #D9DEE4"}}>
          <Block layout horizontal justifyBetween>
          <Block>
            <h1 style={{fontWeight:100, paddingTop:"0.25em"}}>  <FAIcon name="bars" style={{cursor:"pointer"}} onClick={this.toggleCollapse} /> </h1>
          </Block>
            <Block>
              <Reverse alerts={this.state.alerts} onShowMore={ ()=>this.setState({modalVisible:true})}/>
            </Block>
          </Block>
          </div>
          </Affix>
          <Switch>
            <Route path="/dashboard" component={() => <Dashboard /> } />
            <Route path="/clinicsites" component={() => <ClinicSites /> }/>
            <Route path="/provisioning" component={() => <Provisioning /> }/>
            <Route path="/policy" component={() => <Policies /> }/>
            <Route path="/users" component={() => <Users /> }/>
            <Route path="/inventory" component={() => <Inventory /> }/>
            <Route path="/settings" component={() => <Settings /> }/>
            <Route component={() => <Dashboard /> } />
            } />
          </Switch>
          </Content>
          <Footer style={{ textAlign: 'center' }}>

          </Footer>
        </Layout>
      </Layout>
      </LocaleProvider>
      </Router>
    );
  }
}

export default App;


const Reverse = (props) => {
  return (
    <Block layout reverse>
    <div style={{paddingTop:"1.5em", cursor:"pointer", paddingRight:"1em"}}>
    <Dropdown overlay={menu} trigger={["click"]}>
      <span>
        Zhiang <Icon type="down" />
      </span>
    </Dropdown>
    </div>
      <div style={{paddingTop:"1em", paddingLeft:"1.5em", paddingRight:"1em", paddingBottom:"0.5em"}}><span style={{marginTop:"1em"}}><Avatar size="medium" icon="user" /></span></div>

      <Popover placement="bottomRight" trigger="hover" title="Warnings Alerts" content={<AlertsPopover onShowMore={props.onShowMore} AlertsPopover={props.onShowMore} data={props.alerts.filter(a=>a.Status==='Warning')} visible={props.visible} onVisibleChange={props.handleVisibleChange}/>}>
      <div style={{paddingLeft:"1em", paddingTop:"1.5em", cursor:"pointer"}} ><Badge count={props.alerts.filter(a=>a.Status==='Warning').length} showZero>
              <FAIcon title="Warnings" style={{ fontSize: 22, color:"#FFA500"}} name="exclamation-triangle" />
            </Badge></div>
      </Popover>
      <Popover trigger="hover" title="Information Alerts" content={<AlertsPopover onShowMore={props.onShowMore} data={props.alerts.filter(a=>a.Status==='Info')} />}>
      <div style={{paddingLeft:"1em", paddingTop:"1.5em", cursor:"pointer"}} flex><Badge count={props.alerts.filter(a=>a.Status==='Info').length} showZero>
              <FAIcon title="Info" style={{ fontSize: 22, color:"#f46d43"}} name="exclamation-circle" />
            </Badge></div>
      </Popover>
      <Popover trigger="hover" title="Critical Alerts" content={<AlertsPopover onShowMore={props.onShowMore} data={props.alerts.filter(a=>a.Status==='Critical')}/>}>
      <div style={{paddingLeft:"1em", paddingTop:"1.5em", cursor:"pointer"}} flex><Badge count={props.alerts.filter(a=>a.Status==='Critical').length} showZero>
              <FAIcon title="Critical" style={{ fontSize: 22, color:"#a50026"}} name="times-circle" />
            </Badge></div>
        </Popover>
    </Block>
  );
};

const AlertsPopover = (props) => {
  const columns = [{
  title: 'Timestamp',
  dataIndex: 'Time',
}, {
  title: 'Category',
  dataIndex: 'Category',
}, {
  title: 'Action',
  render: (text, record) => <span>Review</span>
}];

  return (
    <div>
    <Table columns={columns} dataSource={props.data} size="middle" pagination={false} scroll={{ y: 240 }}/>
    <br />
    <div style={{cursor:"pointer"}} onClick={props.onShowMore}><a>Show All</a></div>
    </div>
    )
}
