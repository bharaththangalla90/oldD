import React from 'react'
import {Card, Steps, Button, Row, Col} from 'antd'
import {MerakiContent, ISEUserContent, umbrellaContent, cloudLockContent} from './provisioningContents'
import { Collapse, message } from 'antd';
import { Input, InputNumber } from 'antd';
import { Form } from 'antd';

const FormItem = Form.Item;
const Panel = Collapse.Panel;
const Step = Steps.Step;

const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };

const translateVPNData = (data) => {
    const vpnProps = data.map(d => {return {localSubnet:d.subnet_ip, useVpn:d.useVpn}})
    return vpnProps;
}

const translateVlanData = (data) => {
    let vlanObject = {}
    for (let i = 0; i < data.length; i++) {
        let index = "vlan_" + (i + 1)
        vlanObject[index] = data[i]
    }
    return vlanObject;
}

const translateMerakiData = data => {

	let clinicData = {meraki: {organization: { name:'Cisco HC', networks: {}}}}

	data.map( clinic => {
        let vlan = translateVlanData(clinic.vlanProps)
		clinicData.meraki.organization.networks[clinic.networkName] =
			{
				deploy_type:clinic.clinicType,
				address:clinic.address,
                vlans: [vlan],
				vpn:[
					{type: "hub"},
					{hubs: [{hubid:"", useDefaultRoute:true}]},
						    {subnets: translateVPNData(clinic.vlanProps)
			    			}
		    		]
	    	}
	})
    //console.log("Clinic Data::" + JSON.stringify(clinicData))
	return clinicData;
}


class MultiMeraki extends React.Component {
	state = {
		number:1,
		clinics: [],
		organizationName: 'Cisco HC'
	}

	onChange = (value) => {
		if(value > 10) value = 10;
		if(value < 1) value = 1;
	  	this.setState({number:value})
	}

	onChangeOrganizationName = (e) => this.setState({organisationName:e.target.value})

	onChangeSerialNo = (e) => this.setState({serialNo:e.target.value})

	setClinic = (id, details) => { let newClinics = this.state.clinics.slice(); newClinics[id]=details; this.setState({isValid: true, clinics:newClinics}) }

	validateData = () => {
		this.setState({validating:true}, () => {
			fetch("http://10.195.77.27:5001/validation",
			{
			    headers: {
			      'Content-Type': 'application/json'
			    },
			    method: "POST",
			    body: JSON.stringify(translateMerakiData(this.state.clinics))
			})
			.then(res => res.text() )
			.then(data => this.setState({validating: false}, () => {
				if(data.indexOf('following devices are not available ') > -1)
					message.error(data, 10)
				else if(data.indexOf(' is available for creating' > -1)) { message.success(data, 10); this.setState({isValid:true}) }
				else message.error(data, 10)
				}
				))
			.catch(res => this.setState({validating: false}, () => alert(res)))
		})
	}

	submitDeployment = () => {
		this.setState({submitting:true}, () => {
			fetch("http://173.36.210.207/deploystart",
			{
			    headers: {
			      'Content-Type': 'application/json'
			    },
			    method: "POST",
			    body: JSON.stringify(translateMerakiData(this.state.clinics))
			})
			.then(res => res.text() )
			.then(data => this.setState({submitting: false}, () => message.success(data, 10)))
			.catch(res => this.setState({submitting: false}, () => alert(res)))
		})
	}

	render() {
		  return (
		  	<div>
		  		<FormItem
			          {...formItemLayout}
			          label="Organization Name"
			        >
					  <Input disabled type="text" className="Form-control" id="organisationName" placeholder="Enter Organization Name" value={this.state.organizationName} onChange={this.onChangeOrganizationName} />
					</FormItem>
			  	<Form>
			  	<FormItem
			          {...formItemLayout}
			          label="Serial Number/Order Number"
			          hasFeedback
			        >
	                         <Input type="text" className="Form-control" placeholder="Enter Serial Or Order Number" value={this.state.serialNo} onChange={this.onChangeSerialNo} />
               	</FormItem>
			  	<FormItem
		          {...formItemLayout}
		          label="Number of clinics"
		        >
					<InputNumber min={1} max={10} defaultValue={this.state.number} onChange={this.onChange} />
			  	</FormItem>
			  	<FormItem
		          {...formItemLayout}
		          label="Clinic Details"
		        >
					<Collapse bordered={false} defaultActiveKey={['1']}>
						{[...Array(this.state.number)].map((d,i) => <Panel style={{backgroundColor:"#FAFAFA"}} header={"Clinic " + (i+1) + " Configuration"} key={i+1} > <MerakiContent id={i} sendToParent={this.setClinic} /> </Panel> )}
			  		</Collapse>
			  	</FormItem>
				</Form>
				<br />
				<Row gutter={16}>
	              <Col span={4} offset={8}>
			     <Button size="large" value="Validate" loading={this.state.validating} onClick={this.validateData}>Validate</Button>
			     </Col>
			     <Col span={4}>
	             	<Button size="large" type="primary" loading={this.state.submitting} disabled={!this.state.isValid} value="Submit" onClick={this.submitDeployment} >Submit</Button>
             	</Col>
             	</Row>
		  </div>
		  )
	}
}

class ISEContents extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            usersList: [{id:this.getRandomID(), name:"", email: "", password: "", Group:""}], //Show one row by default
            iseIP: "",
            iseusername: "",
            isepassword: ""
        }
    }

    getRandomID = () => {
        return (+ new Date() + Math.floor(Math.random() * 999999)).toString(36)
    }

    addRow = () => {
        this.state.usersList.push({id: this.getRandomID(), name:"", email: "", password: "", Group:""})
        this.setState({usersList:this.state.usersList, isValid: false})
    }

    removeRow = (id) => {
        const index = this.state.usersList.findIndex(Obj => Obj.id === id)
        this.state.usersList.splice(index, 1)
        this.setState({usersList: this.state.usersList})
        this.validateData(this.state.usersList)
    }

    onChangeISEIP = (e) => this.setState({iseIP:e.target.value})
    onChangeISEUsername = (e) => this.setState({iseusername:e.target.value})
    onChangeISEPassword = (e) => this.setState({isepassword:e.target.value})

    validateData = (usersList) => {
        const formValid = usersList.filter(data => (data.name !== "" && data.email !== "" && data.password !== "" &&  data.Group !== ""))
        this.setState({isValid: formValid.length === usersList.length})
    }

    setUsers = (id, name, value) => {
        let usersList = this.state.usersList
        for (var i = 0; i < usersList.length; i++) {
            if (usersList[i].id === id) {
                usersList[i][name] = value
                usersList[i].id = id
            }
        }
        this.setState({usersList:usersList});
        this.validateData(usersList)
    }

    translateISEData = (data) => {
        return {
            "ise": {
                "ers_pass": this.state.isepassword,
                "ers_user": this.state.iseusername,
                "ipaddress": this.state.iseIP,
                "adduser": data
            }
        }
    }

    submitDeployment = () => {
        //console.log("User Data::" + JSON.stringify(this.translateISEData(this.state.usersList)))
        this.setState({submitting:true}, () => {
            fetch("http://10.195.77.27:5001/ise",
            {
                headers: {
                  'Content-Type': 'application/json'
                },
                method: "POST",
                body: JSON.stringify(this.translateISEData(this.state.usersList))
            })
            .then(res => res.text() )
            .then(data => this.setState({submitting: false}, () => message.success(data, 10)))
            .catch(res => this.setState({submitting: false}, () => alert(res)))
        })
    }

    render() {
        return (
            <div>
                <Form className="Form-control">
                    <FormItem {...formItemLayout} label="ISE IP" >
                        <Input type="text" className="Form-control" id="iseIpAddress" placeholder="Enter ISE IP" name="iseIpAddress" value={this.state.iseIP} onChange={this.onChangeISEIP}/>
                    </FormItem>
                    <FormItem {...formItemLayout} label="ISE User Name" >
                        <Input type="text" className="Form-control" id="iseUserName" placeholder="Enter ISE User Name" name="iseUserName" value={this.state.iseusername} onChange={this.onChangeISEUsername} />
                    </FormItem>
                    <FormItem {...formItemLayout} label="ISE Password" >
                         <Input type="password" className="Form-control" id="isePassword" placeholder="Enter ISE Password" name="isePassword" value={this.state.isepassword} onChange={this.onChangeISEPassword}/>
                     </FormItem>
                    <FormItem {...formItemLayout} label="User Details" >
                        <table id="userTable" className="table table-striped">
                            <thead>
                                <tr>
                                    <th width="150">Username</th>
                                    <th width="150">Email</th>
                                    <th width="150">Password</th>
                                    <th width="150">UserGroup</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.state.usersList.map((d,i) => <ISEUserContent key={i} index={i} id={d.id} add={this.addRow} remove={this.removeRow} lastRow={this.state.usersList.length === i+1 ? true : false} sendToParent={this.setUsers} usersList={this.state.usersList[i]}/> )}
                            </tbody>
                        </table>
                    </FormItem>
                </Form>
                <br />
                <Row gutter={16}>
                    <Col span={2} offset={11}>
                        <Button size="large" type="primary" loading={this.state.submitting} disabled={!this.state.isValid} value="Submit" onClick={this.submitDeployment} >Submit</Button>
                    </Col>
                </Row>
            </div>
        )
    }
}


const steps = [{
	title:"Clinic Networks",
	key:0,
	content: <div><MultiMeraki /></div>
},
{
	title:"Users",
	key:1,
    content:<div><ISEContents /></div>
},
{
	title:"Security",
	key:2,
	content:<Collapse style={{backgroundColor:'#FAFAFA'}} bordered={false} defaultActiveKey={['1', '2']}><Panel key={1} header={<h3>Umbrella</h3>}> {umbrellaContent}</Panel><Panel key={2} header={<h3>CloudLock</h3>}>{cloudLockContent}</Panel></Collapse>
},
{
	title:"Applications",
	key:3,
	content:<div></div>
}
]


export default class Provisioning extends React.Component {
	state= {
		current:0
	}

	setCurrent = k => this.setState({current:k})

	render() {
	return  (<div> <br /><Card title="Provisioning" noHovering={true}>
				<Steps current={this.state.current}>
				    {steps.map( s=> <Step key={s.key} title={s.title} description={s.description} style={{cursor:"pointer"}} onClick={()=>this.setCurrent(s.key)}/>)}
				  </Steps>
				  <div className="steps-content">{steps[this.state.current].content}</div>
				  <br />
				  <Button type="primary" disabled>Submit</Button>
			  </Card></div>)
	}
}

/*

    <Panel header="This is panel header 1" key="1">
      <p>{text}</p>
    </Panel>
    <Panel header="This is panel header 2" key="2">
      <p>{text}</p>
    </Panel>
    <Panel header="This is panel header 3" key="3">
      <p>{text}</p>
    </Panel>
  </Collapse>*/
