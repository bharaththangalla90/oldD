import React from 'react';
import { Form, Icon, Input, InputNumber, Button, Select, Row, Col, Switch } from 'antd';

const Option = Select.Option;
const FormItem = Form.Item;

const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 18 },
      },
    };

export const cloudLockContent = <Form id="cloudlockDeployForm" class="form-horizontal" ng-submit = "formSubmit()">

						  <FormItem
					          {...formItemLayout}
					          label="Name"
					        >
							<Input type="text" class="form-control" id="cloudlockName" placeholder="Enter Name" name="cloudlockName" ng-model = "cloudlockName" />
						  </FormItem>
						 <FormItem
				          {...formItemLayout}
				          label="IP Address"
				        >
							<Input type="text" class="form-control" id="cloudlockIpAddress" placeholder="Enter IP Address" name="cloudlockIpAddress" ng-model = "cloudlockIpAddress" />
						  </FormItem>
					  </Form>;

export const umbrellaContent = <Form id="umbrellaDeployForm" class="form-horizontal" ng-submit = "formSubmit()">

		                                 <FormItem
								          {...formItemLayout}
								          label="Name"
								        >
		                                        <Input type="text" class="form-control" id="umbrellaName" placeholder="Enter Name" name="umbrellaName" ng-model = "umbrellaName" />
		                                  </FormItem>
		                                <FormItem
								          {...formItemLayout}
								          label="IP Address"
								        >
	                                        <Input type="text" class="form-control" id="umbrellaIpAddress" placeholder="Enter IP Address" name="umbrellaIpAddress" ng-model = "umbrellaIpAddress" />
		                                  </FormItem>
		                          </Form>

export class ISEUserContent extends React.Component {
    onChangeField = (e) => (this.props.sendToParent(this.props.id, e.target.name, e.target.value))
    onChangeDropdown = (value) => (this.props.sendToParent(this.props.id, "Group", value))

    render() {
        return (
            <tr>
                <td id="Name"><Input name="name" type="text" value={this.props.usersList.name} onChange={this.onChangeField}/></td>
                <td id="Email"><Input name="email" type="text" value={this.props.usersList.email} onChange={this.onChangeField}/></td>
                <td id="Password"><Input name="password" type="password" value={this.props.usersList.password} onChange={this.onChangeField}/></td>
                <td id="UserGroup">
                    <Select name="Group" value={this.props.usersList.Group} onChange={this.onChangeDropdown}>
                    <Option value="">Select an item</Option>
                    <Option value="Employee" selected>Employee</Option>
                    <Option value="Patient">Patient</Option>
                    <Option value="Admin">Admin</Option>
                   </Select>
                </td><td>
                    {(this.props.lastRow) ? (
                    <Icon
                    type="plus-circle"
                    onClick={()=> this.props.add()}
                    />) : null}
                    {(this.props.index !== 0) ? (
                    <Icon
                    type="minus-circle"
                    onClick={() => this.props.remove(this.props.id)}
                    />) : null}
                </td>
            </tr>
        )
    }
}

export class MerakiContent extends React.Component {

	state = {
		vlanConfig: false,
		vpnConfig: false,
        vpnType: "hub",
        customizedClinic: [{device:'MX100', count: 0}, {device:'MR42', count:0}, {device:'MV24', count:0}],
        vlanProps: [{id: 0, vlan_name: "", subnet_ip: "192.168.180.0/24", appliance_ip: "192.168.180.1", vlan_id: 10, useVpn: "false"}]
    }

    getNextIP = (ip) => {
        let temp = ip.split(".")
        temp[2] = Number(temp[2]) + 1
        temp = temp[0] + "." + temp[1] + "." + temp[2] + "." + temp[3]
        return temp
    }

    onSetCustomClinicDevice = (device, value) => {
        let deviceList = this.state.customizedClinic
        for (var i = 0; i < deviceList.length; i++) {
            if (deviceList[i].device === device) {
                deviceList[i]["count"] = value
            }
        }
        this.setState({customizedClinic:deviceList}, ()=> this.props.sendToParent(this.props.id, this.state));
    }

    toggleVLAN = () => this.setState({vlanConfig:!this.state.vlanConfig})

    onChangeVlanProperties = (id, name, value) => {
        let vlanItems = this.state.vlanProps
        for (var i = 0; i < vlanItems.length; i++) {
            if (vlanItems[i].id === id) {
                vlanItems[i][name] = value
            }
        }
        this.setState({vlanProps:vlanItems}, ()=> this.props.sendToParent(this.props.id, this.state));
    }

    addVlan = () => {
        let id = this.state.vlanProps.length
        let vlanItems = this.state.vlanProps;
        vlanItems.push({
            id: id,
            vlan_name: "",
            subnet_ip: this.getNextIP(this.state.vlanProps[this.state.vlanProps.length - 1].subnet_ip),
            appliance_ip: this.getNextIP(this.state.vlanProps[this.state.vlanProps.length - 1].appliance_ip),
            vlan_id: Number(this.state.vlanProps[this.state.vlanProps.length - 1].vlan_id) + 1,
            useVpn: "false"
        })
        this.setState({vlanProps: vlanItems})
    }

    removeVlan = (id) => {
        const index = this.state.vlanProps.findIndex(Obj => Obj.id === id)
        this.state.vlanProps.splice(index, 1)
        this.setState({usersList: this.state.vlanProps})
    }

    toggleVPN = () => this.setState({vpnConfig: !this.state.vpnConfig})

    onChangeNetworkName = (e) => this.setState({networkName:e.target.value}, ()=> this.props.sendToParent(this.props.id, this.state))

    onChangeAddress = (e) => this.setState({address:e.target.value}, ()=> this.props.sendToParent(this.props.id, this.state))

    onChangeClinicType = (value, label) => this.setState({clinicType:value}, ()=>this.props.sendToParent(this.props.id, this.state))

    onChangeVlanName = (e) => this.setState({vlanName:e.target.value}, ()=> this.props.sendToParent(this.props.id, this.state))

    onChangeSubnetIp = (e) => this.setState({subnetIp:e.target.value}, ()=> this.props.sendToParent(this.props.id, this.state))

    onChangeApplianceIp = (e) => this.setState({applianceIp:e.target.value}, ()=> this.props.sendToParent(this.props.id, this.state))

    onChangeVlanId = (e) => this.setState({vlanId:e.target.value}, ()=> this.props.sendToParent(this.props.id, this.state))

    onChangeVpnType = (value, label) => this.setState({vpnType:value}, ()=>this.props.sendToParent(this.props.id, this.state))

    onChangeSubnets = (e) => this.setState({subnets:e.target.value}, ()=> this.props.sendToParent(this.props.id, this.state))

    render() {
		return (
			<Form>
					<FormItem
			          {...formItemLayout}
			          label="Clinic Name"
			          hasFeedback
			        >
						<Input type="text" className="Form-control" id="networkName" placeholder="Enter Clinic Name" value={this.state.networkName} onChange={this.onChangeNetworkName} />
					</FormItem>

	                <FormItem
			          {...formItemLayout}
			          label="Clinic Address"
			          hasFeedback
			        >
			            <Input type="text" className="Form-control" id="ipAddress"  placeholder="Enter Clinic Address" value={this.state.address} onChange={this.onChangeAddress} />
	                </FormItem>

					<FormItem
			          {...formItemLayout}
			          label="Clinic Type"
			          hasFeedback
			        >
									<Select value={this.state.clinicType} onChange={this.onChangeClinicType} >
										<Option title="MX64W: 0, MS220-8P: 0, MV21: 1" value="small">Small</Option>
										<Option title="MX64W: 1, MS220-8P: 1, MV21: 0" value="medium" >Medium</Option>
										<Option title="MX64W: 1, MS220-8P: 2, MV21: 1" value="large" >Large</Option>
										<Option value="customized" > Customized</Option>

									</Select>

					  </FormItem>
                      {this.state.clinicType === 'customized' ?
                        (<FormItem
                          {...formItemLayout}
                          label="Device Name"
                         >
                            <table><tbody>
                                {this.state.customizedClinic.map((d,i) => <CustomClinicType key={i} id={d.device} sendToParent={this.onSetCustomClinicDevice} customizedClinic={this.state.customizedClinic[i].device}/> )}
                            </tbody></table>
                         </FormItem>
                        ): null}

					 <FormItem
			          {...formItemLayout}
			          label="VLAN"
		        	>
			            <Switch checked={this.state.vlanConfig} onChange={this.toggleVLAN} />
			        </FormItem>
					{this.state.vlanConfig == true ?
							(<FormItem
                          {...formItemLayout}
                          label="Vlan Details"
                         >
                            <Row>
                            <Col className="tblHead" span={6}>Vlan Name</Col>
                            <Col className="tblHead" span={7}>Subnet IP</Col>
                            <Col className="tblHead" span={6}>Appliance IP</Col>
                            <Col className="tblHead" span={3}>Vlan ID</Col>
                            <Col className="tblHead" span={2}></Col>
                            </Row>
                                {this.state.vlanProps.map((d,i) => <LoadVlanProperties key={i} index={i} id={d.id} addVlan={this.addVlan} removeVlan={this.removeVlan} lastRow={this.state.vlanProps.length === i+1 ? true : false} sendToParent={this.onChangeVlanProperties} vlanItems={this.state.vlanProps[i]}/> )}
                         </FormItem>
                        ): null}
					<FormItem
			          {...formItemLayout}
			          label="VPN"
			          hasFeedback
			        >
						<Switch checked={this.state.vpnConfig} onChange={this.toggleVPN} />
					</FormItem>
    				  {
    				  	this.state.vpnConfig ?
    				  	<FormItem>
    					  	<FormItem
    				          {...formItemLayout}
    				          label="VPN Type"
    				          hasFeedback
    				        >
    							<Select value={this.state.vpnType} onChange={this.onChangeVpnType} >
    								<Option value="hub" selected >Hub </Option>
    								<Option value="spoke" >Spoke </Option>
    							</Select>
    				  		</FormItem>
    				  		<br />
    						<FormItem
    				          {...formItemLayout}
    				          label="VPN Details"
    				          hasFeedback
    				        >
                            <Row>
                                <Col className="tblHead" span={6}>Vlan Name</Col>
                                <Col className="tblHead" span={8}>Subnet IP</Col>
                                <Col className="tblHead" span={6}>Vlan ID</Col>
                                <Col className="tblHead" span={4}>Use VPN</Col>
                            </Row>
                                {this.state.vlanProps.map((d,i) => <LoadVpnProperties key={i} id={d.id} sendToParent={this.onChangeVlanProperties} vlanItems={this.state.vlanProps[i]}/> )}
    					  	</FormItem>
    				  </FormItem>
    				  : <div />}
		    </Form>
			)
	}
}

class CustomClinicType extends React.Component {
    onChangeDeviceCount = (value) => (this.props.sendToParent(this.props.id, value))

    render() {
        return (
            <tr>
                <td id="Device">
                    <Input name="device" value={this.props.customizedClinic} disabled />
                </td>

                <td id="DeviceCount">
                    <InputNumber id={this.props.id} min={0} max={10} defaultValue={0} onChange={this.onChangeDeviceCount} />
                </td>
            </tr>
        )
    }
}


class LoadVlanProperties extends React.Component {
    onChangeVlanConfig = (e) => (this.props.sendToParent(this.props.id, e.target.name, e.target.value))

    render() {
        return (
            <Row>
                <Col span={6}>
                    <Input name="vlan_name" placeholder="Vlan Name.." value={this.props.vlanItems.vlan_name} onChange={this.onChangeVlanConfig} />
                </Col>
                <Col span={7}>
                    <Input name="subnet_ip" value={this.props.vlanItems.subnet_ip} onChange={this.onChangeVlanConfig} />
                </Col>
                <Col span={6}>
                    <Input name="appliance_ip" value={this.props.vlanItems.appliance_ip} onChange={this.onChangeVlanConfig}/>
                </Col>
                <Col span={3}>
                    <Input name="vlan_id" value={this.props.vlanItems.vlan_id} onChange={this.onChangeVlanConfig}/>
                </Col>
                <Col span={2}>
                {this.props.lastRow ?
                (<Icon
                    type="plus-circle"
                    onClick={()=> this.props.addVlan()}
                    />) : <div/>
                }
                {(this.props.index !== 0) ? (
                    <Icon
                    type="minus-circle"
                    onClick={() => this.props.removeVlan(this.props.id)}
                    />) : <div/>}
                </Col>
            </Row>
        )
    }
}

class LoadVpnProperties extends React.Component {
    onChangeUseVpn = (value) => (this.props.sendToParent(this.props.id, "useVpn", value))

    render() {
        return (
            <Row>
                <Col span={6}>
                    <Input name="vlan_name" value={this.props.vlanItems.vlan_name} disabled/>
                </Col>
                <Col span={8}>
                    <Input name="subnet_ip" value={this.props.vlanItems.subnet_ip} disabled />
                </Col>
                <Col span={6}>
                    <Input name="vlan_id" value={this.props.vlanItems.vlan_id} disabled/>
                </Col>
                <Col span={4}>
                <Select value={this.props.vlanItems.useVpn} onChange={this.onChangeUseVpn} >
                    <Option value="false" selected >No</Option>
                    <Option value="true" >Yes </Option>
                </Select>
                </Col>
            </Row>
        )
    }
}
