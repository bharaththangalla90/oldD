import React from 'react';
import {Legend, Resizable, ChartContainer, ChartRow, YAxis, Charts, AreaChart, styler} from 'react-timeseries-charts';
import { TimeSeries } from "pondjs";
import moment from 'moment';
import {Card} from 'antd';
import { DatePicker } from 'antd';
import { TimeRange } from "pondjs";

const RangePicker = DatePicker.RangePicker;

const columnNames = ['Active', 'Failed']
const activeColor = "#24BC9F";
const failedColor = "#E74C3C";

const chartStyle = {
    "Active": {
        line: {
                        normal: {stroke: activeColor, fill: "none", strokeWidth: 1},
        },
            area: {
            normal: {fill: activeColor, stroke: "none", opacity: 1.0},
        }
    },
    "Failed": {
         line: {
            normal: {stroke: failedColor, fill: "none", strokeWidth: 1},
        },
            area: {
            normal: {fill: failedColor, stroke: "none", opacity: 1.0},
        }
    }
}

const legendStyle = styler([
    { key: "Active", color: "#24BC9F", opacity:1.0, width: 2 },
    { key: "Failed", color: "#E74C3C", opacity:1.0, width: 2 }
]);

const prepareData = data => {    
    const name = "series";
    const columns = ["time", ...columnNames];
    const points = data.map( d => {
        //console.log(d);
        return [moment(d.date_time), d.Active, d.Failed]
    });

    //console.log(points);
    //console.log(series);
    points.sort(function (left, right) {
        return moment(left[0]).diff(moment(right[0]))
    });
    //console.log(points);

    const series = new TimeSeries({ name, columns, points });

    

    return series;
}

export default class ClinicSiteHistory extends React.Component {

    state = {
        ready: false,
        data: new TimeSeries()        
    }

    componentWillMount() {
        /*fetch('http://10.195.77.27:5000/network_history_data')
        .then( response => response.json())
        .then(data => this.setState({data: prepareData(data), ready: true, timerange:prepareData(data).range()}))*/
        if(this.props.ready)
        this.setState({data: prepareData(this.props.data), ready: this.props.ready, timerange:prepareData(this.props.data).range()});
    }

    componentWillReceiveProps(nextProps) {
        /*fetch('http://10.195.77.27:5000/network_history_data')
        .then( response => response.json())
        .then(data => this.setState({data: prepareData(data), ready: true, timerange:prepareData(data).range()}))*/
        if((this.props.ready != nextProps.ready) && nextProps.ready )
        this.setState({data: prepareData(nextProps.data), ready: nextProps.ready, timerange:prepareData(nextProps.data).range()});
    }

    handleTimeRangeChange = (timerange) => {
        //console.log(JSON.stringify(timerange))
    if (timerange) {
      this.setState({ timerange, brushrange: timerange });
    } else {
      this.setState({ timerange: this.state.data.timerange(), brushrange: null });
    }
  }

  handleDatePicker = (dates, dateStrings) => {
        let range = new TimeRange(dates[0], dates[1]);
        this.setState({ timerange:range, brushrange:range });
        //console.log('From: ', dates[0], ', to: ', dates[1]);
        //console.log('From: ', dateStrings[0], ', to: ', dateStrings[1]);
    }

    render() {
        let euroValue='-', audValue='-';
        if (this.state.tracker) {
            const index = this.state.data.bisect(this.state.tracker);
            const trackerEvent = this.state.data.at(index);
            audValue = `${(trackerEvent.get("Active"))}`;
            euroValue = `${(trackerEvent.get("Failed"))}`;
        }

        return (
            <Card title={"Clinic Site History"} loading={!this.props.ready} extra={<RangePicker
              ranges={{ Today: [moment().startOf('day') , moment().endOf('day') ], 'This Month': [moment().startOf('month'), moment().endOf('month')] }}
              showTime
              format="YYYY/MM/DD HH:mm:ss"
              onChange={this.handleDatePicker} />}
            >
            <div>
            <Legend
                            type="swatch"
                            style={legendStyle}
                            align="right"                            
                            highlight={this.state.highlight}
                            onHighlightChange={highlight =>
                                this.setState({ highlight })}
                            selection={this.state.selection}
                            onSelectionChange={selection =>
                                this.setState({ selection })}
                            categories={[
                                { key: "Active", label: "Active", value: audValue },
                                { key: "Failed", label: "Failed", value: euroValue }
                            ]}
                        />
            <Resizable>            
            <ChartContainer 
            onTrackerChanged={(tracker) => this.setState({tracker})}
            trackerPosition={this.state.tracker}
            timeRange={this.state.timerange}            
            onTimeRangeChanged={this.handleTimeRangeChange}
            >
                    <ChartRow height="120">
                        <YAxis
                            id="y"
                            min={0}
                            max={10}
                            width="60"                            
                            type="linear"
                            />
                        <Charts>
                            <AreaChart                            
                                axis="y"
                                info={"test"}
                                style={chartStyle}
                                series={this.state.data}
                                columns={{up:["Active", "Failed"], down:[]}}
                                fillOpacity={1}
                                interpolation="curveStepAfter" />
                        </Charts>
                    </ChartRow>
                </ChartContainer>
            </Resizable>
            </div>            
            </Card>
            )
    }
}

/*


                */