import React from 'react';
import {Resizable, Charts, ChartContainer, ChartRow, BarChart, YAxis, styler} from 'react-timeseries-charts';
import {TimeSeries, Index, TimeRange} from 'pondjs';
import { DatePicker, Card, Table } from 'antd';
import moment from 'moment';

const RangePicker = DatePicker.RangePicker;

const data = [
    ["2017-01-24 00:00", 0.01],
    ["2017-01-24 01:00", 0.13],
    ["2017-01-24 02:00", 0.07],
    ["2017-01-24 03:00", 0.04],
    ["2017-01-24 04:00", 0.33],
    ["2017-01-24 05:00", 0.2],
    ["2017-01-24 06:00", 0.08],
    ["2017-01-24 07:00", 0.54],
    ["2017-01-24 08:00", 0.95],
    ["2017-01-24 09:00", 1.1],
    ["2017-01-24 10:00", 0.66],
    ["2017-01-24 11:00", 0.06],
    ["2017-01-24 12:00", 0.3],
    ["2017-01-24 13:00", 0.05],
    ["2017-01-24 14:00", 0.5],
    ["2017-01-24 15:00", 0.24],
    ["2017-01-24 16:00", 0.02],
    ["2017-01-24 17:00", 0.98],
    ["2017-01-24 18:00", 0.46],
    ["2017-01-24 19:00", 0.8],
    ["2017-01-24 20:00", 0.39],
    ["2017-01-24 21:00", 0.4],
    ["2017-01-24 22:00", 0.39],
    ["2017-01-24 23:00", 0.28]
];

const series = new TimeSeries({
    name: "hilo_rainfall",
    columns: ["index", "precip"],
    points: data.map(([d, value]) => [
        Index.getIndexString("1h", new Date(d)),
        value*100
    ])
});


export default class SecurityActivity extends React.Component {

  state = {
    timerange:series.range(),
    selection: null
  }

  handleTimeRangeChange = (timerange) => {
        //console.log(JSON.stringify(timerange))
    if (timerange) {
      this.setState({ timerange, brushrange: timerange });
    } else {
      this.setState({ timerange: this.state.data.timerange(), brushrange: null });
    }
  }

  handleDatePicker = (dates, dateStrings) => {
        let range = new TimeRange(dates[0], dates[1]);
        this.setState({ timerange:range, brushrange:range });
        //console.log('From: ', dates[0], ', to: ', dates[1]);
        //console.log('From: ', dateStrings[0], ', to: ', dateStrings[1]);
    }

	render () {
    const style = styler([
            { key: "precip", color: "#73879C"},
        ]);

    const columns = [{
      title: 'Timestamp',
      dataIndex: 'timestamp',
    }, {
      title: 'Events',
      dataIndex: 'data',
    }, {
      title: 'Action',
      dataIndex: 'action',
    }]

  	return (
      <Card title="Security Alerts" extra={<RangePicker
              ranges={{ Today: [moment().startOf('day') , moment().endOf('day') ], 'This Month': [moment().startOf('month'), moment().endOf('month')] }}
              showTime
              format="YYYY/MM/DD HH:mm:ss"
              onChange={this.handleDatePicker} />}
            >            
    	<Resizable>
        <ChartContainer timeRange={series.range()} 
          enablePanZoom 
          timeRange={this.state.timerange}
          enablePanZoom={true}
          onTimeRangeChanged={this.handleTimeRangeChange}
        >
            <ChartRow height="150">
                <YAxis
                    id="rain"
                    label="Events"
                    min={0}
                    max={150}                    
                    width="70"
                    type="linear"
                />
                <Charts>
                    <BarChart
                        axis="rain"
                        style={style}
                        spacing={1}
                        columns={["precip"]}
                        series={series}
                        selected={this.state.selection}
                        onSelectionChange={
                          selection => {console.log(selection.event.toJSON()); this.setState({ selection })}   
                        }
                    />
                </Charts>
            </ChartRow>
        </ChartContainer>
    </Resizable>
    {this.state.selection ? <div><br/><Table columns={columns} dataSource={[{key:1, timestamp:JSON.stringify(this.state.selection.event.timestamp()), data:this.state.selection.event.toJSON().data.precip}]} size="middle" pagination={false} /> </div>: ""}
    </Card>
    );
  }
}
