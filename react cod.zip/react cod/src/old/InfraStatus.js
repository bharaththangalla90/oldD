import React from 'react';
import moment from 'moment';

// Pond
import { TimeSeries, TimeRangeEvent, TimeRange, Collection } from "pondjs";

// Imports from the charts library
import {YAxis, ChartContainer, ChartRow, Charts, EventChart ,Resizable, Brush, AreaChart} from "react-timeseries-charts";

import {Row, Col, Badge, Card} from 'antd';
import { DatePicker } from 'antd';

const RangePicker = DatePicker.RangePicker;

//
// Test data
//

let outageEvents = [
    {
        startTime: moment().subtract(3, 'hour'),
        endTime: moment().subtract(2, 'hour'),
        title: "Active",
        description: "ANL will be switching border routers...",
        completed: true,
        external_ticket: "",
        esnet_ticket: "ESNET-20150302-002",
        organization: "ANL",
        type: "Planned"
    },
    {
        startTime: moment().subtract(2, 'hour'),
        endTime: moment().subtract(1, 'hour'),
        title: "Inactive",
        description: "The listed circuit was unavailable due to bent pins.",
        completed: true,
        external_ticket: "3576:144",
        esnet_ticket: "ESNET-20150421-013",
        organization: "Internet2 / Level 3",
        type: "Unplanned"
    },
    {
        startTime: moment().subtract(1, 'hour'),
        endTime: moment().add(7, 'hour'),
        title: "Active",
        description: "The listed circuit was unavailable due to bent pins.",
        completed: true,
        external_ticket: "3576:144",
        esnet_ticket: "ESNET-20150421-013",
        organization: "Internet2 / Level 3",
        type: "Unplanned"
    }    
];

let longSeries = [];
let statuses = ['Active','Active','Active','Active','Inactive']

for(let i=1000; i>0; i--) {
    let event = {
        startTime: moment().subtract(i, 'hour'),
        endTime: moment().subtract(i-1, 'hour'),
        title: statuses[Math.floor(Math.random()*statuses.length)]
    }
    longSeries.push(event);
}

outageEvents = longSeries;


//
// Turn data into TimeSeries
//

const events = outageEvents.map(
    ({ startTime, endTime, ...data }) =>
        new TimeRangeEvent(
            new TimeRange(new Date(startTime), new Date(endTime)),
            data
        )
);
const series = new TimeSeries({ name: "outages", events });

var fmt = "YYYY-MM-DD HH:mm";
var beginTime = moment().startOf('day');
var endTime =   moment();
var range = new TimeRange(beginTime, endTime);

//
// Render event chart
//

function outageEventStyleFunc(event, state) {
    const color = event.get("status") === "Active" ? "#1ABB9C" : "#E74C3C";
    switch (state) {
        case "normal":
            return {
                fill: color
            };
        case "hover":
            return {
                fill: color,
                opacity: 0.4
            };
        case "selected":
            return {
                fill: color
            };
        default:
        //pass
    }
}

const prepareData = data => {

    let sortedData = data.data.sort(function (left, right) {
                     return moment(left.start_time).diff(moment(right.start_time))
                        });

    if(sortedData.filter( e => e.status=='Inactive').length==0) sortedData = [{start_time:sortedData[0].start_time, end_time:sortedData[sortedData.length-1].end_time, status:"Active"}]

    const events = sortedData.map(
    ({ start_time, end_time, ...data }) =>
        new TimeRangeEvent(
            new TimeRange(new Date(start_time), new Date(end_time)),
            data
        )
    );

    //console.log(events);


    // events.sort(function (left, right) {
    //     return moment(left.start_time).diff(moment(right.start_time))
    // });

    let newEvents = new Collection(events);

//    console.log("Test")
//    console.log(newEvents.isChronological())

  //  console.log(newEvents);

    const series = new TimeSeries({ name: "outages", events });

    //console.log("DEBUG")
    //console.log("old")
    //console.log(events)
    //prepareAllData(data)

    return series
}

const prepareAllData = rawData => {
    rawData = [{start_time:rawData[0].start_time, end_time:rawData[rawData.length-1].end_time, status:"Active"}]
    const events = rawData.map(d => d.data.map(
    ({ start_time, end_time, ...data }) =>
        new TimeRangeEvent(
            new TimeRange(new Date(start_time), new Date(end_time)),
            data
        )
    ));

    //console.log("new")
    //console.log(events[0])
    let ev = events[0]
    let t = new TimeSeries({ name: "outages", ev })

    return events.map( e => new TimeSeries({ name: "outages", e }));
}

const brushStyle = {
      boxShadow: "inset 0px 2px 5px -2px rgba(189, 189, 189, 0.75)",
      background: "#FEFEFE",
      paddingTop: 10
    };

export default class InfraStatus extends React.Component {
    state = {
        
            tracker: null,
            timerange: range,
            data: [],
            dataMeraki: [],
            dataISE:[],
            dataUmbrella: [],
            dataCloudLock: [],
            services: []        
    }

    componentWillMount() {
        /*fetch('http://10.195.77.27:5000/system_health')
        .then( response => response.json())
        .then(data => this.setState({dataMeraki: prepareData(data[0]), dataISE: prepareData(data[1]), dataCloudLock: prepareData(data[3]), dataUmbrella: prepareData(data[3]), services: data.map(d=>d.app), ready: true}))*/

        if(this.props.ready) {
            let data = this.props.data;
            this.setState({dataMeraki: prepareData(data[0]), dataISE: prepareData(data[1]), dataCloudLock: prepareData(data[3]), dataUmbrella: prepareData(data[3]), services: ['Meraki', ' ISE', 'CloudLock', 'Umbrella']});
        }        

    }

    componentWillReceiveProps(nextProps) {
        /*fetch('http://10.195.77.27:5000/system_health')
        .then( response => response.json())
        .then(data => this.setState({dataMeraki: prepareData(data[0]), dataISE: prepareData(data[1]), dataCloudLock: prepareData(data[3]), dataUmbrella: prepareData(data[3]), services: data.map(d=>d.app), ready: true}))*/

        if((this.props.ready != nextProps.ready) && nextProps.ready ) {
            let data = nextProps.data;
            this.setState({dataMeraki: prepareData(data[0]), dataISE: prepareData(data[1]), dataCloudLock: prepareData(data[3]), dataUmbrella: prepareData(data[3]), services: ['Meraki', ' ISE', 'CloudLock', 'Umbrella']});
        }        

    }

    handleTrackerChanged = (tracker) => {
        this.setState({ tracker });
    }


    handleDatePicker = (dates, dateStrings) => {
        let range = new TimeRange(dates[0], dates[1]);
        this.setState({ timerange:range, brushrange:range });
        //console.log('From: ', dates[0], ', to: ', dates[1]);
        //console.log('From: ', dateStrings[0], ', to: ', dateStrings[1]);
    }


    handleTimeRangeChange = (timerange) => {
        //console.log(JSON.stringify(timerange))
    if (timerange) {
      this.setState({ timerange, brushrange: timerange });
    } else {
      this.setState({ timerange: this.state.dataMeraki.timerange(), brushrange: null });
    }
  }
    render() {
        const series = this.state.dataMeraki;
        const series1 = this.state.dataISE;
        const series2 = this.state.dataCloudLock;
        const series3 = this.state.dataUmbrella;
        return (            
            <Card title={"Infrastructure Status"} loading={!this.state.services.length} extra={<RangePicker
              ranges={{ Today: [moment().startOf('day') , moment().endOf('day') ], 'This Month': [moment().startOf('month'), moment().endOf('month')] }}
              showTime
              format="YYYY/MM/DD HH:mm:ss"
              onChange={this.handleDatePicker}              
            />} ><br />            
            <div>
            <Row>
                <Col span={4} style={{marginTop:"-5px"}}>
                {
                    this.state.services.map( (d,i) => {
                        return (
                            <div key={i} style={{height:30, fontSize:"16px"}}> <Badge status="success" /> {d} </div>
                            )
                    })

                }                
                </Col>
                <Col span={20}>                
                        <Resizable>
                            <ChartContainer
                                timeRange={this.state.timerange}                                
                                onTimeRangeChanged={this.handleTimeRangeChange}
                                tracker
                            >                                
                                <ChartRow height="30">                                
                                    <Charts>
                                        <EventChart
                                            series={series}
                                            size={45}
                                            style={outageEventStyleFunc}
                                            label={e => e.get("status")}
                                        />
                                    </Charts>
                                </ChartRow>
                                <ChartRow height="30">
                                    <Charts>
                                        <EventChart
                                            series={series1}
                                            size={45}
                                            style={outageEventStyleFunc}
                                            label={e => e.get("status")}
                                        />
                                    </Charts>
                                </ChartRow>
                                <ChartRow height="30">
                                    <Charts>
                                        <EventChart
                                            series={series2}
                                            size={45}
                                            style={outageEventStyleFunc}
                                            label={e => e.get("status")}
                                        />
                                    </Charts>
                                </ChartRow>
                                <ChartRow height="30">
                                    <Charts>
                                        <EventChart
                                            series={series3}
                                            size={45}
                                            style={outageEventStyleFunc}
                                            label={e => e.get("status")}
                                        />
                                    </Charts>
                                </ChartRow>
                            </ChartContainer>
                        </Resizable>
                        <br />                
                </Col>
            </Row>                
        </div>        
            </Card>            
        );
    }
}