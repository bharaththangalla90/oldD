import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment'
import {Card, Col, Row, Button, Modal} from 'antd'
import { Select, Switch, Icon } from 'antd';
import {Table, Timeline, Alert} from 'antd'

import {
  XYPlot,
  XAxis,
  YAxis,
  makeWidthFlexible,
  AreaSeries
} from 'react-vis';

const Option = Select.Option;

const interpolations = ['curveLinear', 'curveNatural', 'curveStepBefore', 'curveStepAfter', 'curveCardinal'];
const interpolationOptions = [];

for (let i = 0; i < interpolations.length; i++) {
  interpolationOptions.push(<Option key={interpolations[i]}>{interpolations[i]}</Option>);
}

const abbreviateNumber = num => {
  let powerOfTen = Math.round(num).toString().length - 1;
  let threeDigitPrefix = num / Math.pow(10, Math.floor((powerOfTen)/3)*3)
  let suffix = ['', 'k', 'M', 'B', 'T'][Math.floor((powerOfTen)/3)]
  
  //console.log(num, powerOfTen, threeDigitPrefix, suffix)

  return threeDigitPrefix.toString() + suffix
}

class DomainInfo extends React.Component {
  state = { visible: false }
  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = (e) => {
    //console.log(e);
    this.setState({
      visible: false,
    });
  }
  handleCancel = (e) => {
    //console.log(e);
    this.setState({
      visible: false,
    });
  }
  render() {
    return (
      <div>
        <Button type="dashed" onClick={this.showModal} shape="circle" icon="search" />        
        <Modal
          title={"Domain Information for " + this.props.domain}
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <Alert message="This domain is currently blocked by Umbrella" type="error" />
          <br /><Alert message="Classified as benign" type="success" />
          <br /><Alert message="Umbrella Risk Score: +100" type="success" />
        </Modal>
      </div>
    );
  }
}


const FlexibleXYPlot = makeWidthFlexible(XYPlot);

const columns = [{
  title: 'Category',
  dataIndex: 'category',
}, {
  title: 'Requests',
  dataIndex: 'totalRequests',
  render: text => <div style={{textAlign:"right"}}>{text} </div>
}];

const mostBlockedColumns = [{
  title: 'Domain',
  dataIndex: 'domain',
}, {
  title: 'More Info',
  dataIndex: 'moreInfo',
  render: (text, record) => <DomainInfo domain={record.domain} />
}];

const mostBlockedDomains = [
{
  domain: 'internetbadguys.com',
  moreInfo: 'some info'
},
{
  domain: 'news.com.com',
  moreInfo: 'some info'
},
{
  domain: 'thepreambleproject.com',
  moreInfo: 'some info'
}
]


export default class NetworkStream extends React.Component {
  state = {    
    hoveredIndex: false,
    selectedCategories: [],
    interpolation: "curveLinear",
    umbrella_data: [],
    allData: [],
    blockedData: [],
    dates:[],
    categoryOptions: <div />,
    showTable: false
  }

  toggleTableView = c => this.setState({showTable:c})

  setSelectedCategories = c => this.setState({selectedCategories:c})
  
  setInterpolation = c => this.setState({interpolation:c})

  componentWillMount() {
  	fetch('http://10.195.77.53:8088/network_stream')
  	.then( response => response.json())
  	.then( data => this.setState({umbrella_data:data}, () =>
  	{
  		const categoriesNew = Array.from(new Set(this.state.umbrella_data.data.map( d => d.countsByCategory.map(c => c.label ) ).reduce((a,b) => a.concat(b))))
	  	const categoryOptions = [];
		for (let i = 0; i < categoriesNew.length; i++) {
		  if(categoriesNew[i].length) categoryOptions.push(<Option key={categoriesNew[i]}>{categoriesNew[i]}</Option>);
		}

	  	const getTraffic = (c,d,type) => {
			const entry = this.state.umbrella_data.data.find(x => x.fromTimestamp === d).countsByCategory.find(y => y.label === c);
			if(entry) return type==='blocked'? entry.blockedRequests: entry.totalRequests;
			else return 0
		}

		const dates = this.state.umbrella_data.data.map(d => d.fromTimestamp)

		const allData = categoriesNew.map(c => { return {category:c, data:dates.map( d=> { return {x:d, y:getTraffic(c, d, 'total')}})}})
		allData.unshift({category:'dummy', data:dates.map(d=> {return {x:d, y:0}})})
		
		let mostTraffic = allData.map(d => {return {category:d.category, totalRequests:d.data.reduce( (acc, item) => acc + item.y, 0)}}).filter( d=> d.category !=='all' && d.category !=='allowed' && d.category !=='blocked')

		//console.log(mostTraffic)
		
		mostTraffic.sort((a,b) => b.totalRequests - a.totalRequests)


		//console.log(mostTraffic)

		const blockedData = categoriesNew.map(c => { return {category:c, data:dates.map( d=> { return {x:d, y:getTraffic(c, d, 'blocked')}})}})
		blockedData.unshift({category:'dummy', data:dates.map(d=> {return {x:d, y:0}})})

		let mostBlocked = blockedData.map(d => {return {category:d.category, totalRequests:d.data.reduce( (acc, item) => acc + item.y, 0)}}).filter( d=> d.category !=='all' && d.category !=='allowed' && d.category !=='blocked')

		//console.log(mostTraffic)
		
		mostBlocked.sort((a,b) => b.totalRequests - a.totalRequests)

		//console.log(mostTraffic)

		this.setState({mostBlocked: mostBlocked.slice(0,5), mostTraffic:mostTraffic.slice(0,5), allData:allData, blockedData:blockedData, dates:dates, categoryOptions:categoryOptions})

  	}))
  }

  getGraph = () => {

    let bigTableColumns = [{
        title: 'Category',
        dataIndex: 'category',
        fixed: 'left',
        width: 150,
        sorter: (a, b) => a.category.localeCompare(b.category),
      }];

    if (this.state.allData[0]) this.state.allData[0].data.map( d => bigTableColumns.push({title:moment(d.x).format('D-MMM'), dataIndex:moment(d.x).format('D-MMM')}));
    
    const {hoveredIndex} = this.state;
    const filteredData = this.state.selectedCategories.length ? this.state.allData.filter(d => this.state.selectedCategories.indexOf(d.category) > -1): this.state.allData.filter(d => d.category !=='all' && d.category !=='blocked' && d.category !== 'allowed');

    filteredData.sort( (a,b) => a.data.reduce( (acc, item) => acc + item.y, 0) - b.data.reduce( (acc, item) => acc + item.y, 0))

    

    let tabularStream = filteredData.filter(d => d.category !=='dummy').map( d => {
      let entry = {category:d.category};
      d.data.map(t => entry[moment(t.x).format('D-MMM')]=t.y)
      return entry
    })


    filteredData.unshift({category:'dummy', data:this.state.dates.map(d=> {return {x:d, y:0}})});

    return (<div>
    	<Row gutter={16}>      
      <Col xs={24} sm={24} md={16} lg={16} xl={16}>
      <Card style={{marginBottom:"3em"}}
      title={<div>Network Activity
            <h6 style={{color:"#aaa"}}>{this.state.hoveredIndex ? filteredData[this.state.hoveredIndex].category: this.state.selectedCategories.length ? "":"Excluded: all, allowed, blocked" }</h6></div> }
      extra={this.state.categoryOptions.length ? <div>
         <Select
          mode="multiple"
          style={{ width: '24em' }}
          placeholder="choose categories"    
          onChange={ this.setSelectedCategories }
          defaultValue={this.state.selectedCategories}
        >
          {this.state.categoryOptions}
        </Select>{"  "}
        <Switch checkedChildren={<Icon type="bars" />} unCheckedChildren={<Icon type="bars"/>} checked={this.state.showTable} onChange={this.toggleTableView} />
        </div> : null
      }>
      <div className="streamgraph-example">       
        <div className="streamgraph">
        {
        	this.state.umbrella_data.status ?
        		<FlexibleXYPlot colorRange={['#36CAAB', '#86dfcc' , '#207966' ]}   colorDomain={[0, 1, 2]}   colorType="category"
		            stackBy="y"
		            animation
		            onMouseLeave={() => this.setState({hoveredIndex: false})}
		            height={335}>
		            <XAxis tickFormat= {t => { return moment(t).format('D-MMM') }} tickTotal={9}/>
		            <YAxis tickFormat= { v => abbreviateNumber(v) }  tickTotal={7} />
		            {filteredData.map((series, index) => (
		              <AreaSeries
                    color={index}
		                key={index}
		                curve={this.state.interpolation}
		                style={this.state.hoveredIndex ? index === hoveredIndex ? {opacity:1}:{opacity:0.1}:{}}
		                onSeriesMouseOver={(e) => { this.setState({hoveredIndex: index})}}
		                data={series.data} />
		            ))}            
	          	</FlexibleXYPlot>
	          	:
	          	<div />
        }
        </div>             
      </div>
      {this.state.showTable ? <Table columns={bigTableColumns} dataSource={tabularStream} scroll={{ x: 2000, y: 240}}  />:null}
      </Card>
      </Col>
      <Col xs={24} sm={24} md={8} lg={8} xl={8}>
      <Card title={"Top DNS Categories"}>
        <Table columns={columns} dataSource={this.state.mostTraffic} size="middle" pagination={false} />
        </Card>
      
      </Col>
      </Row>
     </div>

    );
  }

  render () {
  	if(this.state.umbrella_data.status) return this.getGraph()
  		else return <div />

  }

}

NetworkStream.propTypes = {
  forFrontPage: PropTypes.bool
};
