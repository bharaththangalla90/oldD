import { Table, Tag, Tooltip } from 'antd';
import React from 'react';
import moment from 'moment';


const getTag = severity => {
  if(severity === 'Critical') return <Tag color="red">Critical</Tag>
  if(severity === 'Info') return <Tag color="blue">Info</Tag>
  else return <Tag color="orange">{severity}</Tag>
}

export default class AlertsTable extends React.Component {
  render() {
    return (<Table className="alertTable" loading={!this.props.dataReady} columns={columns} dataSource={this.props.data} onChange={onChange} />)
  }
}

const columns = [{
  title: 'Timestamp',
  dataIndex: 'Time',
  width: '15%',
  sorter: (a, b) => moment(a.Time).diff(moment(b.Time)),
}, {
  title: 'Category',
  dataIndex: 'Category',
  filters: [{
    text: 'Meraki',
    value: 'Meraki',
  }, {
    text: 'CloudLock',
    value: 'CloudLock',
  }],
  filterMultiple: true,
  onFilter: (value, record) => record.Category.indexOf(value) === 0,
  sorter: (a, b) => a.Category.localeCompare(b.Category),
},
{
  title: 'Item',
  width: '30%',
  render: (text, record) => <span><span className="showMore">{record.Item}</span>
  <Tooltip title={record.Category === "Meraki" ? <p>{record.Details}</p> : <span><p><b>Name</b>: {record.name}</p><p><b>Email</b>: {record.email}</p></span>} placement="topLeft">
     <a>  More..</a>
  </Tooltip>
  </span>
},
{
  title: 'Severity',
  dataIndex: 'Status',
  filters: [{
    text: 'Critical',
    value: 'Critical',
  }, {
    text: 'Warning',
    value: 'Warning',
  }, {
    text: 'Info',
    value: 'Info',
  }],
  render: (text, record) => getTag(record.Status),
  filterMultiple: true,
  onFilter: (value, record) => record.Status.indexOf(value) === 0,
  sorter: (a, b) => a.Status.localeCompare(b.Status),
},
{
  title: 'Action',
  render: (text, record) => <span>Review</span>,
}];


function onChange(pagination, filters, sorter) {
  console.log('params', pagination, filters, sorter);
}

