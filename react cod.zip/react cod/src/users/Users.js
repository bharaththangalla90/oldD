import React from 'react'
import {Card, Tabs} from 'antd'
import {MerakiUserContainer} from './MerakiUsers'


const TabPane = Tabs.TabPane;

export default class Users extends React.Component {

    callback(key) {
      //console.log(key);
    }

    render() {
    return  (<div><br /><Card title="Users" noHovering={true}>
                <Tabs defaultActiveKey="1" onChange={this.callback}>
                    <TabPane tab="Meraki" key="1">
                        <MerakiUserContainer />
                    </TabPane>
                    <TabPane disabled tab="Umbrella" key="2" style={{minHeight:"200px"}}><span style={{minHeight:"300px"}}> Umbrella Users...</span></TabPane>
                    <TabPane disabled tab="CloudLock" key="3" style={{minHeight:"200px"}}><span style={{minHeight:"300px"}}> CloudLock Users..</span></TabPane>
                </Tabs>
              </Card></div>)
    }
}

