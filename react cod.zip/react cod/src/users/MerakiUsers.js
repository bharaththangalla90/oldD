import React from 'react'
import {Collapse, Row, Col, Table, Button, Modal, Form, Input, Select, message} from 'antd'

const FormItem = Form.Item;
const Option = Select.Option;
const Panel = Collapse.Panel;

const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };

const columns = [
      { title: 'Name', dataIndex: 'name',},
      { title: 'Email', dataIndex: 'email' },
      { title: 'Access', dataIndex: 'orgAccess'},      
    ];


export class MerakiAdmins extends React.Component {
    state = {

    }

    componentWillMount() {
      fetch('http://10.195.77.53:8090/api/v0.1/meraki/api/v0/organizations/620316/admins')
      .then( response => response.json())
      .then(data => this.setState({admins:data}))
    }

    render() {      
        return (<Table columns={columns} dataSource={this.state.admins} onChange={onChange} loading={!this.state.admins} />)
    }
}

export class AddMerakiAdmin extends React.Component {
    state = {
        policyConfig : {
          policy: "Allow",
          protocol: "TCP",
          destinationip: "",
          port: "",
          comments: ""
        }
    }

    onUpdateFirewallPolicies = (field, value) => {
      let Object = this.state.policyConfig
      Object[field] = value
      this.setState({policyConfig: Object}, ()=> this.props.sendToParent(this.state))
    }

    onFirewallPolicyChange = (value) => {
      this.onUpdateFirewallPolicies("policy", value)
    }

    onFirewallProtocolChange = (value) => {
      this.onUpdateFirewallPolicies("protocol", value)
    }

    onUpdateField = (e) => {
      this.onUpdateFirewallPolicies(e.target.name, e.target.value)
    }

    render() {
        return (<Form className="Form-control">

            <FormItem {...formItemLayout} label="Policy" >
            <Select name="policy" value={this.state.policyConfig.policy} onChange={this.onFirewallPolicyChange}>
                <Option value="Allow">Allow</Option>
                <Option value="Deny">Deny</Option>
           </Select>
            </FormItem>
            <FormItem {...formItemLayout} label="Destination IP" >
                <Input type="text" className="Form-control" placeholder="Enter Destination IP" name="destinationip" value={this.state.policyConfig.destinationip} onChange={this.onUpdateField} />
            </FormItem>
            <FormItem {...formItemLayout} label="Protocol" >
            <Select name="protocol" value={this.state.policyConfig.protocol} onChange={this.onFirewallProtocolChange}>
                <Option value="TCP">TCP</Option>
                <Option value="UDP">UDP</Option>
                <Option value="ICMP">ICMP</Option>
                <Option value="Any">Any</Option>
           </Select>
            </FormItem>
            <FormItem {...formItemLayout} label="Port" >
                 <Input type="text" className="Form-control" placeholder="Enter Port" name="port" value={this.state.policyConfig.port} onChange={this.onUpdateField}/>
            </FormItem>
            <FormItem {...formItemLayout} label="Comments" >
                 <Input type="textarea" rows={4} className="Form-control" placeholder="Enter Comments" name="comments" value={this.state.policyConfig.comments} onChange={this.onUpdateField}/>
            </FormItem>
        </Form>)
    }
}

export class MerakiUserContainer extends React.Component {

    state = {
        modalVisible: false
    }

    updatePolicyConfigs = (configs) => {
      let policyObject = {}
      policyObject.rules = [configs.policyConfig]
      this.setState({policyConfig: policyObject})
    }

    saveFirewallRule = (e) => {
      console.log("Final data::" + JSON.stringify(this.state.policyConfig))
      fetch("https://dashboard.meraki.com/api/v0/networks/L_664280945037149361/ssids/0/l3FirewallRules",
      {
          headers: {
            'X-Cisco-Meraki-API-Key': '1c64bdf35e2ba69edd50a164506da3b3f5f75411',
            'Content-Type': 'application/json'
          },
          method: "POST",
          body: this.state.policyConfig
      })
      .then(res => res.text() )
      .then(data => message.success(data, 10))
      .catch(res => alert(res))

        this.setState({
          modalVisible: false,
        });
    }

    handleCancel = (e) => {
      this.setState({
        modalVisible: false,
      });
    }

    addFirewallRule() {
      this.setState({modalVisible: true});
    }

    callback(key) {
      //console.log(key);
    }

    render() {
        return (<div>
          <Collapse accordion defaultActiveKey={['1']} onChange={this.callback} >
            <Panel header="Admins" key="1">
              <Row>
                <Col style={{marginBottom:"15px"}} span={2} offset={22}><Button onClick={()=>this.setState({modalVisible: true})} type="primary" disabled >Add Admin</Button></Col>
                <Col span={24}><MerakiAdmins /></Col>
              </Row>
            </Panel>
            <Panel header="Other Users" key="2" disabled>
              <p>Under development...</p>
            </Panel>           
          </Collapse>
          <Modal
            width={600}
            title="Add Meraki Admin"
            visible={this.state.modalVisible} okText="Save"
            onOk={this.saveFirewallRule}
            onCancel={this.handleCancel}
          >
              <AddMerakiAdmin sendToParent={this.updatePolicyConfigs}/>
          </Modal>
        </div>)
    }
}

function onChange(pagination, filters, sorter) {
  console.log('params', pagination, filters, sorter);
}


