import React from 'react';
import {Tooltip} from 'antd';
import {VictoryAxis} from 'victory';
import moment from 'moment'
import ContainerDimensions from 'react-container-dimensions'

const services = ['Meraki', 'ISE', 'CloudLock', 'Umbrella']

const getSystemHealthDateRange = data => {
	if(data.length)
	{
		let startRanges = data.map( d => moment(d.data[0].start_time).valueOf())
		let endRanges = data.map( d => moment(d.data[d.data.length-1].end_time).valueOf())

		let range = ({from:Math.min(...startRanges), to:Math.max(...endRanges)})
		//console.log(startRanges, range)
		return range
	}

	return null
	
}

export default class InfraGraph extends React.Component {
	
	render() {

		let range = getSystemHealthDateRange(this.props.system_health)

		return this.props.system_health.length ? (<ContainerDimensions>
		{  ({ width, height }) => {

				let axisWidth = width >= 752 ? 662: width/12*8.685;

				return (<div>{this.props.system_health.map( (d,i) => <EventGraph key={i} serviceName={d.app} data={d.data} serviceIndex={i} onResize={this.onResize} width={width} range={range} />)}
				<div><svg width={axisWidth} height={35} >
						<VictoryAxis
							tickCount={Math.round(axisWidth/70)}
							domain={[moment(range.from), moment(range.to)]}
							width={axisWidth}
							standalone={false}
						  	scale={{x: "time"}}
						  	offsetY={290}
						  	fixLabelOverlap
						  	style={{
							    axis: {stroke: "rgb(188, 197, 205)"},    
							    ticks: {stroke: "rgb(188, 197, 205)", size: 5},
							    tickLabels: {fontSize: 12, padding: 5, fill:"rgb(188, 197, 205)"}
							  }}					  	
						/>
				</svg></div>
					</div>)
				}
			}</ContainerDimensions>):<h1>Loading....</h1>;
	}
}

class EventGraph extends React.Component {
	

render() {

	const slices = this.props.width >= 752 ? 80: Math.round(this.props.width/12)
	const sliceInterval = Math.round((this.props.range.to-this.props.range.from)/slices)
	const inActiveTimes = this.props.data.filter( d => d.status !== 'Active')

	//console.log('inActiveTimes', inActiveTimes)


return (<div className="matchstick-chart" id={"matchstick-chart-"+this.props.serviceIndex}>
			<div className="matchstick-chart-label" style={{textAlign:"right"}}>{this.props.serviceName}</div>
		{[...Array(slices)].map((d,i) => {

			let stickStartTime = moment(this.props.range.from+i*sliceInterval)
			let stickEndTime = moment(this.props.range.from+(i+1)*sliceInterval)

			let stickColor = "#1ABB9C"
			inActiveTimes.map( d => { if(moment(d.start_time).valueOf() <= stickEndTime.valueOf() && moment(d.end_time).valueOf() >= stickStartTime.valueOf()) stickColor = '#E74C3C' })

		return   <Tooltip key={i} title={<div>
			<p style={{textAlign:"center"}}>{`${stickStartTime.format('ddd, h:mm')} - ${stickEndTime.format('ddd, h:mm')}`}</p>
			<p style={{textAlign:"center"}}>No incidents</p>
			</div>}>
		<div className="matchstick-chart-stick" style={{backgroundColor:stickColor}}></div></Tooltip>})
		}
		<div className="matchstick-chart-label" style={{textAlign:"left"}}>100.0%</div>
		</div>
		)
}
}
