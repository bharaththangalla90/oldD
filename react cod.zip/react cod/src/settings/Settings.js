import React from 'react'
import {Table, Checkbox} from 'antd'

const columns = [{
  title: 'App',
  dataIndex: 'app',
}, {
  title: 'Sidebar Link',
  dataIndex: 'sidebar_link',
  render: text =>   <Checkbox
            defaultChecked={text}            
          > </Checkbox>
}, {
  title: 'Dashboard Panel',
  dataIndex: 'dashboard',
  render: text =>   <Checkbox
            defaultChecked={text}            
          > </Checkbox>
}, {
  title: 'Notifications',
  dataIndex: 'notifications',
  render: text =>   <Checkbox
            defaultChecked={text}            
          > </Checkbox>
}];

const data = [{
  key: '1',
  app: 'Provisioning',
  sidebar_link: true,
  dashboard: false,
  notifications: false
}, {
  key: '2',
  app: 'Clinic Status',
  sidebar_link: true,
  dashboard: true,
  notifications: false
}, {
  key: '3',
  app: 'Network Activity',
  sidebar_link: false,
  dashboard: true,
  notifications: true
}];



export default class Settings extends React.Component {
	
	render () {

		return (
			<div>
			<br />
			<Table 
		    style={{backgroundColor:"#fff"}}		    
		    columns={this.props.columns || columns} 
		    dataSource={this.props.data || data} 
		    pagination={false} />
		    </div>
			)
	}
}