import React from 'react'
import {Card, Col, Popover, Button} from 'antd'

const SizeLink = props => <span onClick={props.onClick} style={{cursor:"pointer", padding:" 0 5px 0 5px", fontWeight:props.highlight ? "bold":"normal", color:props.highlight ? "#1ABB9C": props.disabled ? "#ddd":"#73879C" }}>{props.children}</span>

export class DashCard extends React.Component {
	state = {
		size:this.props.size || "m"
	}

	setSize = newSize => this.setState({size:newSize})

	render() {

		let gridSize = this.state.size === 'l' ? 16 : 8;

		return (
			<Col xs={24} sm={24} md={gridSize} lg={gridSize} xl={gridSize}>
				<Card style={{marginRight:"8px", marginLeft:"8px"}} title={<div style={{cursor:"move"}}>{this.props.title}</div>}  extra={<Popover
			        content={
			        	<div>
			        		<div>App Size: <SizeLink disabled>S</SizeLink><SizeLink onClick={e=>this.setSize('m')} highlight={this.state.size==='m'} >M</SizeLink><SizeLink onClick={e=>this.setSize('l')} highlight={this.state.size==='l'}>L</SizeLink></div>
			        		
					        <div style={{color:"#ddd", marginTop:"5px"}}> Remove App </div>
				        </div>
			        	}
			        placement="bottomRight" trigger="click"
			      >
			        <div> <Button type="dashed" icon="ellipsis" shape="circle" /> </div>			        
			      </Popover>}>
					{this.props.children}
				</Card>
			</Col>
		)
	}
}

/*
<Dropdown overlay={menu} trigger={['click']} loading={this.props.loading} >
		                                                    <div>                                                    
		                                                    <Icon type="ellipsis" />
		                                                    </div>
		                                                  </Dropdown>

		                                                  */
