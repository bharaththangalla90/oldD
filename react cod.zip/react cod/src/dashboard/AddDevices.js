import React from 'react';
import { Modal, Button, Table, Input, Form, message } from 'antd';
import moment from 'moment';

const Search = Input.Search;
const FormItem = Form.Item;

const success = text => {
  message.success(text);
};

const error = text => {
  message.error(text);
};


const columns = [
{
  title:"Model",
  dataIndex: "model"
},
{
  title:"Serial Number",
  dataIndex: "serial"
},
{
  title:"Claimed At",
  dataIndex: "claimedAt",
  render: text => moment.unix(Math.round(text)).format('MM/DD/YYYY')
},
]

export default class AddDevices extends React.Component {
  state = {
    ModalText: '',
    visible: false,
    searchString: "",
    serialNumber: ""
  }

  setSearchString = e => this.setState({searchString:e.target.value});

  showModal = () => {
    this.setState({
      visible: true,
    });
  }
  handleOk = () => {
    this.setState({
      ModalText: '...',
      confirmLoading: true,
    });
    setTimeout(() => {
      this.setState({
        visible: false,
        confirmLoading: false,
      });
    }, 2000);
  }
  handleCancel = () => {    
    this.setState({
      visible: false,
    });
  }

  claimDevice = () => {
    fetch(`http://10.195.77.53:8090/api/v0.1/meraki/api/v0/networks/${this.state.networkId}/devices/claim`, {
      method: 'post',
      body: JSON.stringify({serial:this.state.serialNumber})
    }).then(function(response) {
      return response.json();
    }).then(function(data) {
      success(data)
    });
  }

  componentWillMount() {

    const urls = ['http://10.195.77.53:8090/api/v0.1/meraki/api/v0/organizations/620316/inventory', 'http://10.195.77.53:8090/api/v0.1/meraki/api/v0/organizations/620316/networks'];

    Promise.all(urls.map(url => fetch(url)))
    .then(responses =>
      Promise.all(responses.map(res => res.json())))
      .then(jsons => { this.setState({availableDevices:jsons[0].filter( device => ! device.networkId), networkId:jsons[1].filter(network => network.name === this.props.networkName)[0].id})})
    }


  render() {
    const rowSelection = {
  onChange: (selectedRowKeys, selectedRows) => {
    console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
  },
  getCheckboxProps: record => ({
    disabled: record.name === 'Disabled User',    // Column configuration not to be checked
  }),
};

    const { visible, confirmLoading, ModalText } = this.state;
    return (
      <div>
        <Button type="primary" onClick={this.showModal}>Add Devices</Button>
        <Modal title={"Add Devices to " + this.props.networkName } 
          visible={visible}
          onOk={this.handleOk}
          okText="Add"
          confirmLoading={confirmLoading}
          onCancel={this.handleCancel}
        >
        <Search
                  placeholder="search inventory"
                  style={{ width: 200 }}
                  value={this.state.searchString}
                  onChange={this.setSearchString}
                /> <br /><br />
          <Table loading={!this.state.availableDevices} dataSource={this.state.availableDevices ? this.state.availableDevices.filter( d=> d.model.indexOf(this.state.searchString) > -1 || d.serial.indexOf(this.state.searchString) > -1 ) : [] } columns={columns} size="medium" rowSelection={rowSelection} pagination={false} />
          <br /> <br />
          <p> Unable to find your device ? You may have to claim it. </p>
          <br />
          <Form layout="inline">
          <FormItem>
              <Input placeholder="Serial Number" value={this.state.serialNumber} onChange={e => this.setState({serialNumber:e.target.value})}/>
          </FormItem> 
          <FormItem>
            <Button onClick={this.claimDevice}>
              Claim
            </Button>
          </FormItem>
        </Form>

          <p>{ModalText}</p>
        </Modal>
      </div>
    );
  }
}
