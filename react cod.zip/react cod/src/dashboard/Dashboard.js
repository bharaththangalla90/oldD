import React from 'react'
import {Row, Col, Table} from 'antd'
import {DashCard as Card} from './DashCard';
import ClinicStatus from '../clinic_status/ClinicStatus'
import {Icon as FAIcon } from 'react-fa';
import EventGraph from '../infrastructure_status/EventGraph';
import NetworkStream from '../network_activity/NetworkStream'
import NoActionsRequired from '../common/NoActionsRequired'
import ServerMonitoring from '../monitoring/server_monitoring'
import AddDevices from './AddDevices'


export default class Dashboard extends React.Component {

	state = {
    clinicNetworkData: [],
    systemHealth: [],
    clinicStatusData:[]
	}

  processSystemHealth = () => {
    let servicesActive = this.state.systemHealth.filter((d) => d.data[d.data.length-1].status==='Active').length;
    this.setState({servicesActive: servicesActive, servicesActivePercentage:Math.round(servicesActive/this.state.systemHealth.length*100)});
  }

  componentWillMount() {
    fetch('http://10.195.77.27:5000/network_history_data')
      .then( response => response.json())
      .then(data => this.setState({clinicNetworkData:data[0].data}))

    fetch('http://10.195.77.27:5000/system_health')
      .then( response => response.json())
      .then(data => this.setState({systemHealth: data, donutDummy:1}, ()=>this.processSystemHealth()))

    fetch('http://10.195.77.27:5000/ise_users')
      .then( response => response.json())
      .then(data => this.setState({totalUsers:data.Total_number_of_Users}))

    const urls = ['http://10.195.77.27:5000/network_inactive_data', 'http://10.195.77.27:5000/network_active_data'];

    Promise.all(urls.map(url => fetch(url)))
    .then(responses =>
      Promise.all(responses.map(res => res.json())))
      .then(jsons => { this.setState({clinicStatusData:arrayize(Object.assign(jsons[0], jsons[1])), clinicStatusDataLoaded:true})})

  }


	render() {

		const servicesActive = this.state.systemHealth.length ? this.state.systemHealth.filter(d => d.data[d.data.length-1].status==='Active').length:0;
		const servicesActivePercentage = this.state.systemHealth.length ? Math.round(servicesActive/this.state.systemHealth.length*100)+'%':<FAIcon spin pulse name="spinner" />;
		const serviceActiveDetails = this.state.systemHealth.length ? servicesActive + ' out of ' + this.state.systemHealth.length + ' active' :'--';

		const clinicsActive = this.state.clinicNetworkData.length ? this.state.clinicNetworkData[this.state.clinicNetworkData.length-1].Active : 0;
		const totalClinics = this.state.clinicNetworkData.length ? this.state.clinicNetworkData[this.state.clinicNetworkData.length-1].Active+this.state.clinicNetworkData[this.state.clinicNetworkData.length-1].Failed : <FAIcon spin pulse name="spinner" />;
		const clinicsActivePercentage = this.state.clinicNetworkData.length ? Math.round(clinicsActive/totalClinics*100)+'%':<FAIcon spin pulse name="spinner" />;
		const clinicsActiveDetails = this.state.clinicNetworkData.length ? clinicsActive + ' out of ' + totalClinics + ' active' :'--';

    const clinicActions = this.state.clinicStatusData.filter(clinic => clinic.data.status==='Failed').map(clinic => {return {name:clinic.data.name, status:clinic.data.status} });

    const clinicActionsColumns = [{key:'name', dataIndex:'name', render: (text, record) => `No devices found for ${text}`}, {
        title: 'Action',
        key: 'status',
        render: (text, record) => (
          <AddDevices networkName={record.name} />
        ),
      }]

		return (
		<div style={{paddingTop:"1em", lineHeight:"2.5em"}} className="content">
          <Row gutter={16} style={{paddingLeft:"2em"}}>
            <Col xs={24} sm={8} md={8} lg={8} xl={8}>
              <FAIcon name="cloud" /> Services Active
              <h1 className="big-number">{servicesActivePercentage}</h1>
              {serviceActiveDetails}
            </Col>
            <Col xs={24} sm={8} md={8} lg={8} xl={8}>
              <FAIcon name="medkit" /> Clinics Active
              <h1 className="big-number">{clinicsActivePercentage}</h1>
              {clinicsActiveDetails}
            </Col>
            <Col xs={24} sm={8} md={8} lg={8} xl={8}>
              <FAIcon name="user" /> Total Users
              <h1 className="big-number" style={{border:"none"}}>{this.state.totalUsers ? this.state.totalUsers: <FAIcon spin pulse name="spinner" /> }</h1>
              <FAIcon name="sort-asc" />x% from last week
            </Col>
          </Row>
          <br />
          <Row gutter={16}>
          <Card title="Clinic Site Status" size="l">
            <div style={{width:"100%", height:"400"}}>
              <ClinicStatus data={this.state.clinicStatusData} />
            </div>
          </Card>
          <Card title={"Clinic Actions"} loading={!this.state.clinicStatusDataLoaded} size="m">
              <div style={{width:"100%", height:"400"}}>
                  <Table dataSource={clinicActions} columns={clinicActionsColumns} loading={this.state.clinicStatusData.length === 0 } showHeader={false} />
              </div>
          </Card>
          </Row>
          <br />
          <Row gutter={16}>
          <Card title={"Infrastructure Status"} loading={this.state.systemHealth.length == 0} size="l"> <div style={{textAlign:"center", height:"313"}}><EventGraph system_health={this.state.systemHealth} /></div></Card>
          <Card title={"Infrastructure Actions"} size="m">
              <div style={{textAlign:"center", height:"313"}}><NoActionsRequired /></div>
          </Card>
          </Row>
          <br />
            <NetworkStream />

              <ServerMonitoring/>
          </div>
		)
	}
}


const arrayize = o => {
  let res = [];
  for(let item in o) {
    res.push({name:item, data:o[item]});
  }
  return res;
}
