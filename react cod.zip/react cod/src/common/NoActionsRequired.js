import React from 'react'

export default class NoActionsRequired extends React.Component {
	render() {
		return (
			<div className="blank-slate-holder"><div className="blank-slate">  <b>Hurray!</b>
  <div className="certificate"><span className="fa-stack fa-spin-hover"><i className="fa fa-certificate fa-stack-2x sun"></i><i className="fa fa-thumbs-up fa-stack-1x box"></i></span></div>
No actions required!    
  </div></div>
		)
	}
}