import {Row, Col} from 'antd';
import React from 'react';

export default class InfoBar extends React.Component {
	render() {

		const color =  this.props.alt ?  "#73879C":"#73879C";
		const weight = this.props.alt ? "bold":"normal";

		return (
		<Row>
			<Col xs={13} sm={9} md={9} lg={7} xl={5}>
				<div style={{textAlign:"right", overflow: "hidden", textOverflow: "ellipsis", fontWeight:weight}}>{this.props.label}</div>
			</Col>
			<Col span={1} />
			<Col span={2}>
				<div style={{textAlign:"right", fontWeight:weight}}>{this.props.value}</div>
			</Col>
			<Col span={1} />
			<Col xs={5} sm={9} md={9} lg={11} xl={13}>
				<div style={{marginTop:5, backgroundColor:'#F0F0F0', height:20, width:'100%'}}><div style={{	backgroundColor:this.props.color || color, height:20, width:this.props.percentage}}>{" "}</div></div>
			</Col>			
		</Row>
		)
	}
}
