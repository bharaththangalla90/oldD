import React from 'react'
import {Card, Collapse, Avatar, Table, Row, Col} from 'antd'

const Panel = Collapse.Panel;

const expandedRowRender = (network) => {
  const columns = [
    { title: 'Model', dataIndex: 'model' },
    { title: 'Serial Number', dataIndex: 'serial' },
    { title: 'Mac Address', render: (text, record) => <p>{record.mac.toUpperCase()}</p>},
    { title: 'Public IP', dataIndex: 'publicIp'},
    { title: 'Claimed At', dataIndex: 'claimedAt'}
  ];

    return (<Table key={network.serial} columns={columns} dataSource={network.data} pagination={false} />);
};

class DeviceDetails extends React.Component {
  state = {}

  componentWillMount() {
    fetch('http://10.195.77.27:5000/org_inventory')
      .then( response => response.json())
      .then( data => {
        const networkList = Array.from(new Set(data.map(k => k.networkId))).map((d, i)=> {return {key: i, name:data.filter(k => k.networkId === d)[0].network_name, data: data.filter(k => k.networkId === d)}})
        this.setState({networkList: networkList})
      })
  }

  render() {
    const columns = [
      { title: 'Network', dataIndex: "name"},
      { title: 'Total Devices', render: (text, record) => <span>{record.data.length}</span> },
    ];
    return <Table
      className="components-table-demo-nested"
      loading = {!this.state.networkList}
      columns={columns}
      dataSource={this.state.networkList}
      expandedRowRender={record=>expandedRowRender(record)}
      onChange={onChange} />
  }
}

class LicenseDetails extends React.Component {
  state = {}

  componentWillMount() {
    fetch('http://10.195.77.53:8090/api/v0.1/meraki/api/v0/organizations/620316/licenseState')
    .then( response => response.json())
    .then( data => this.setState({data:data}))
  }
  render () {

    const merakiDeviceData = this.state.data ? Object.keys(this.state.data.licensedDeviceCounts).map((key, i) => { return { device: key, count: this.state.data.licensedDeviceCounts[key] }}) : [];

    return (
      <div>
      <br />
        <Card title="License Status">
          <Collapse bordered={false}>
              <Panel header={<Row>
                  <Col span={1} offset={1}><Avatar style={this.state.data ? { backgroundColor: '#1ABB9C' }:{}} icon={this.state.data ? "check":"question"} size="small"/></Col>
                  <Col span={4}><h3>Meraki</h3></Col>
                  <Col span={8}>{this.state.data ? "License Expires On: " + this.state.data.expirationDate : ""}</Col>
                  </Row>} key="1">
                      <Row><Col span={7} offset={2} >
                        <Table dataSource={merakiDeviceData} columns={[{title:"Device", dataIndex:"device"}, {title:"Count", dataIndex:"count"}]} size="small" pagination={false} loading={!this.state.data} />
                        </Col>
                      </Row>
              </Panel>
              <Panel header={<Row><Col span={1} offset={1}><Avatar icon="question" size="small"/></Col><Col span={4}><h3>Umbrella</h3></Col></Row>} key="2" disabled>
                <p>---</p>
              </Panel>
              <Panel header={<Row><Col span={1} offset={1}><Avatar icon="question" size="small"/></Col><Col span={4}><h3>CloudLock</h3></Col></Row>} key="3" disabled>
                <p>---</p>
              </Panel>
            </Collapse>
        </Card>
      </div>
      )
  }
}

export default class InventoryDetails extends React.Component {
  callback(key) {
    console.log(key);
  }

  render() {
      return (<div>
        <LicenseDetails/>
        <br />
        <Card title="Devices" noHovering={true}>
        <DeviceDetails/>
        </Card>
        </div>
      )
  }
}

function onChange(pagination, filters, sorter) {
  console.log('params', pagination, filters, sorter);
}

