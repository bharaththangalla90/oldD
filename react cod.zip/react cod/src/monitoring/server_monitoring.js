import React from 'react'
import {Row, Card, Col, Modal, Form, Input, Icon} from 'antd'
import moment from 'moment'
import {VictoryPie, VictoryArea, VictoryGroup, VictoryLegend, VictoryChart, VictoryLabel, VictoryAxis, VictoryVoronoiContainer, VictoryTooltip } from 'victory'

const FormItem = Form.Item;
const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span:  12},
      },
      wrapperCol: {
        xs: { span: 10 },
        sm: { span:  6},
      },
    };

class ThresholdSettings extends React.Component {
  state = {

  }
  updateThresholdSettings = () => {

  }
  render() {
    return (<Form>
          <FormItem
            {...formItemLayout}
            label="Upper Critical"
          >
            <Input type="text" style={{width: '70px'}} className="Form-control" placeholder="" value={this.state.upperCritical} onChange={this.updateThresholdSettings} />%
          </FormItem>
          <FormItem
            {...formItemLayout}
            label="Upper Warning"
            hasFeedback
          >
             <Input type="text" style={{width: '70px'}} className="Form-control" placeholder="" value={this.state.upperWarning} onChange={this.updateThresholdSettings} />%
          </FormItem>
          </Form>)
  }
}


export default class ServerMonitoring extends React.Component {
  state = {
    thresholdModalVisible: false,
    modalVisible: false
  }

  componentWillMount() {
    const urls = ['http://10.195.77.27:5000/system_cpu', 'http://10.195.77.27:5000/system_mem', 'http://10.195.77.27:5000/system_disk'];

    Promise.all(urls.map(url => fetch(url)))
    .then(responses =>
      Promise.all(responses.map(res => res.json())))
      .then(jsons => {
        let systemDetails = []
        let cpuData = jsons[0].filter(item => moment(item.datetime).isAfter(moment(jsons[0][jsons[0].length - 1].datetime).subtract(6, 'hours').format()))
        let memoryData = jsons[1].filter(item => moment(item.datetime).isAfter(moment(jsons[1][jsons[1].length - 1].datetime).subtract(6, 'hours').format()))
        let diskData = jsons[2].filter(item => moment(item.datetime).isAfter(moment(jsons[2][jsons[2].length - 1].datetime).subtract(6, 'hours').format()))
        let cpuDetails = {}
        let memoryDetails = {}
        let diskDetails = {}
        cpuDetails.details = {"name": "CPU", "process": 343,"threads": 23432, "handles": 13233, used:cpuData[cpuData.length - 1]["Cpu_percentage"]}
        cpuDetails.graphData = cpuData.map((d => {return {time:new Date(moment(d.datetime).valueOf()), usage:d.Cpu_percentage}}))

        memoryDetails.details = {name: "Memory", total:memoryData[memoryData.length -1].Total_mem, used: memoryData[memoryData.length -1].Used_mem, usedPercentage: memoryData[memoryData.length -1].Used_mem_percentage}
        memoryDetails.graphData = memoryData.map(d=> {return {time: new Date(moment(d.datetime).valueOf()), usage:d.Used_mem_percentage}})

        diskDetails.details = {name: "Disk", total:diskData[diskData.length -1].Total_space, used: diskData[diskData.length -1].Total_used, usedPercentage: diskData[diskData.length -1].Used_disk_percentage}
        diskDetails.graphData = diskData.map(d=> {return {time: new Date(moment(d.datetime).valueOf()), usage:d.Used_disk_percentage}})

        systemDetails.push(cpuDetails)
        systemDetails.push(memoryDetails)
        systemDetails.push(diskDetails)

        this.setState({systemDetails: systemDetails})
     })
  }

  handleCancel = () => {
    this.setState({modalVisible: false})
  }
  handleOk = () => {
    this.setState({modalVisible: false})
  }
  showModalGraph = (item, title, type ) => {
    if (item === 'graph') {
      this.setState({chartTitle: title + " Usage", graphData: this.state.systemDetails[type].graphData, modalVisible: true})
    } else {
      //this.setState({thresholdModalVisible: true})
    }
  }
    render() {
        return (<span>
          <Row gutter={16}>
          <Col span={16}>
          <Card title={"Clinic InterConnect Server Stats"} loading={!this.state.systemDetails}>
          {this.state.systemDetails ?
          <Row className="server-status">
          <CPUDetails type="0" title="CPU" data={this.state.systemDetails[0].details} offset={0} showModal={this.showModalGraph}/>
          <SystemResourceDetails type="1" title="Memory" data={this.state.systemDetails[1].details} offset={1} showModal={this.showModalGraph} unit={1024*1024*1024} unitValue="GB"/>
          <SystemResourceDetails type="2" title= "Disk" data={this.state.systemDetails[2].details} offset={1} showModal={this.showModalGraph} unit={1024*1024*1024} unitValue="GB"/>
        </Row> : <div/>}
        </Card></Col></Row>

        <Modal className="server-resources"
          width={500}
          title={this.state.chartTitle}
          visible={this.state.modalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
        <ShowGraph data={this.state.graphData}/>
        </Modal>

        </span>)
    }
}

class ShowGraph extends React.Component {

  render() {
    return (
      <Row gutter={24}>
        <Col span={20}>
          <VictoryChart height={300} width={400} domain={{y:[0,100]}} domainPadding={{x:0}} containerComponent={<VictoryVoronoiContainer dimension="x"
            labels= {(d) => `${moment(d.x).format("hh:mm A")}\n ${d.y}%`}
            labelComponent={<VictoryTooltip cornerRadius={2} pointerLength={4} style={{fontSize: 10, fill: "#73879C"}} flyoutStyle={{stroke: "#e9e9e9", fill: "white"}}/>}
          />}>

            <VictoryAxis fixLabelOverlap={false} scale="time"
            style={{
              tickLabels: {fontSize: 10, padding: 5, fill: "#73879C"},
            }} />

            <VictoryAxis dependentAxis tickCount={10} tickFormat={(t) => `${t}%`}
            style={{
              tickLabels: {fontSize: 10, padding: 5, fill: "#73879C"},
              grid: {stroke: (t) => t === 70 ? "#ffa500" : t === 90 ? "#a50026" : ""}
            }} />

            <VictoryGroup
                style={{
                  data: {strokeWidth: 1, fillOpacity: 0.4}
                }}
              >
              <VictoryArea
                style={{
                  data: {fill: "#86dfcc", stroke: "#86dfcc"},
                  parent: { border: "1px solid #ccc"},
                  labels: {fill: "#2B65EC", fontSize: '10px'}
                }}
                data={this.props.data.map(d => {return {x:d.time, y:d.usage}})}
              />
            </VictoryGroup>
          </VictoryChart>
        </Col>
        <Col span={4}>
          <VictoryLegend y={250}
            title="Thresholds"
            centerTitle
            orientation="vertical"
            gutter={10}
            style={{ border: { stroke: "black" }, title: {fontSize: 12 } }}
            data={[
              { name: "Warning", symbol: { type: "square", fill: "#ffa500"}, labels: { fill: "ffa500" } },
              { name: "Critical", symbol: { type: "square", fill: "#a50026"}, labels: { fill: "a50026" } },
            ]}
          />
        </Col>
      </Row>)
  }
}

class CPUDetails extends React.Component {
  render() {
      const item = this.props.data
      return (
        <Col sm={24} xs={7} lg={7} style={{backgroundColor: "#F8F9F9", padding: '10px'}} offset={this.props.offset}>
          <Row className="head">
            <Col span={18}>{item.name}</Col>
            <Col className="action-container" span={6}><Icon type="line-chart" onClick={() => this.props.showModal('graph', this.props.title, this.props.type)}/><Icon type="setting" onClick={this.props.showModal('threshold', this.props.title, this.props.type)}/></Col>
          </Row>
          <Row className="server-status-body">
            <Col xs={9} lg={9} style={{marginTop: '5px'}}><svg width="100%" height="100%" viewBox="0 0 250 250">
              <VictoryPie
                width={250} height={250} colorScale={["#1ABB9C", "#f0f0f0" ]}
                data={[{x: 1, y: item.used}, {x: 2, y:100-item.used}]}
                innerRadius={60} labelRadius={100}
                style={{ labels: { fontSize: 8, fill: "white", display: "none"}}}
              />
              <VictoryLabel
                textAnchor="middle"
                x={125} y={125}
                text={`${item.used}%`} style={{fontFamily: "Arial", fontSize: '30px'}}
              />
              </svg>
            </Col>
            <Col xs={15} lg={15}>
              <Row>
                <Col xs={13} lg={13} >Process:</Col>
                <Col xs={11} lg={11} >{item.process}</Col>
              </Row>
              <Row>
                <Col xs={13} lg={13} >Threads:</Col>
                <Col xs={11} lg={11} >{item.threads}</Col>
              </Row>
              <Row>
                <Col xs={13} lg={13} >Handle:</Col>
                <Col xs={11} lg={11} >{item.handles}</Col>
              </Row>
            </Col>
          </Row>
        </Col>
      )
  }

}

class SystemResourceDetails extends React.Component {

  render() {
      const item = this.props
      return (
      this.props ?
        <Col sm={24} xs={7} lg={7} style={{backgroundColor: "#F8F9F9", padding: '10px'}} offset={this.props.offset}>
          <Row className="head">
            <Col span={18}>{item.data.name}</Col>
            <Col className="action-container" span={6}><Icon type="line-chart" onClick={()=>this.props.showModal('graph', this.props.title, this.props.type)}/><Icon type="setting" onClick={() => this.props.showModal('threshold', this.props.title, this.props.type)}/></Col>
          </Row>
          <Row className="server-status-body">
            <Col xs={9} lg={9} style={{marginTop: '5px'}}><svg width="100%" height="100%" viewBox="0 0 250 250">
              <VictoryPie
                width={250} height={250} colorScale={[((item.data.usedPercentage > 20) && (item.data.usedPercentage < 80)) ? "#ffa500" : (item.data.usedPercentage >= 80) ? "#b94a48" : "#1ABB9C", "#f0f0f0" ]}
                data={[{x: 1, y: item.data.usedPercentage}, {x: 2, y:100-item.data.usedPercentage}]}
                innerRadius={60} labelRadius={100}
                style={{ labels: { fontSize: 8, fill: "white", display: "none"}}}
              />
              <VictoryLabel
                textAnchor="middle"
                x={125} y={125}
                text={`${item.data.usedPercentage}%`} style={{fontFamily: "Arial", fontSize: '30px'}}
              />
              </svg>
            </Col>
            <Col xs={15} lg={15}>
              <Row>
                <Col xs={13} lg={13} >Total Size:</Col>
                <Col xs={11} lg={11} >{Math.round(item.data.total/item.unit)} {item.unitValue}</Col>
              </Row>
              <Row>
                <Col xs={13} lg={13} >Used:</Col>
                <Col xs={11} lg={11} >{Math.round(item.data.used/item.unit)} {item.unitValue}</Col>
              </Row>
              <Row>
                <Col xs={13} lg={13} >Available:</Col>
                <Col xs={11} lg={11} >{Math.round((item.data.total - item.data.used)/item.unit)} {item.unitValue}</Col>
              </Row>
            </Col>
          </Row>
        </Col> : <div/>
      )
  }
}
