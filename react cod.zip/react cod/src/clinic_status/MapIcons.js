import React from 'react'

export class MapMarkerIcon extends React.Component {
	render() {
		return (		
			<svg className="map-icon-shadow" viewBox="0 0 10 10" width="15px">
			  <circle cx="5" cy="5" r="4" stroke-width="1" stroke="#fff" fill={this.props.color}/>
			  
			</svg>
		)
	}
}