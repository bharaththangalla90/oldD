import React from 'react';
import {VictoryGroup, VictoryChart, VictoryStack, VictoryArea, VictoryTooltip, VictoryVoronoiContainer} from 'victory';
import moment from 'moment';
import {Card} from 'antd';
import { DatePicker } from 'antd';
//import { TimeRange } from "pondjs";

const RangePicker = DatePicker.RangePicker;

export default class ClinicSiteHistory extends React.Component {

    state = {
        ready: false,
        data: []
    }

    componentWillMount() {
        /*fetch('http://10.195.77.27:5000/network_history_data')
        .then( response => response.json())
        .then(data => this.setState({data: prepareData(data), ready: true, timerange:prepareData(data).range()}))*/
        if(this.props.ready)
        this.setState({data: this.props.data, ready: this.props.ready});
    }

    componentWillReceiveProps(nextProps) {
        /*fetch('http://10.195.77.27:5000/network_history_data')
        .then( response => response.json())
        .then(data => this.setState({data: prepareData(data), ready: true, timerange:prepareData(data).range()}))*/
        if((this.props.ready != nextProps.ready) && nextProps.ready )
        this.setState({data: nextProps.data, ready: nextProps.ready});
    }

  /*  handleTimeRangeChange = (timerange) => {
        //console.log(JSON.stringify(timerange))
    if (timerange) {
      this.setState({ timerange, brushrange: timerange });
    } else {
      this.setState({ timerange: this.state.data.timerange(), brushrange: null });
    }
  }

  handleDatePicker = (dates, dateStrings) => {
        let range = new TimeRange(dates[0], dates[1]);
        this.setState({ timerange:range, brushrange:range });
        //console.log('From: ', dates[0], ', to: ', dates[1]);
        //console.log('From: ', dateStrings[0], ', to: ', dateStrings[1]);
    }*/

    render() {
        
    return (
        <Card title={"Clinic Site History"} loading={!this.props.ready} extra={<RangePicker
              ranges={{ Today: [moment().startOf('day') , moment().endOf('day') ], 'This Month': [moment().startOf('month'), moment().endOf('month')] }}
              showTime
              format="YYYY/MM/DD HH:mm:ss"
              onChange={this.handleDatePicker} />}
            >
      <div>
        <VictoryChart scale={{x: "time"}} width={800} height={220} 
        containerComponent={
          <VictoryVoronoiContainer
            dimension="x"
            labels={(d) => `${d.type}: ${d.type=='Failed'? d.actualFailed : d.y}`}
            labelComponent={
              <VictoryTooltip
                cornerRadius={0}
                flyoutStyle={{fill: "white"}}
              />}
            />}

        >
          <VictoryStack colorScale={[ "#E74C3C", "#1ABB9C"]}>
            <VictoryGroup
              data={this.state.data.map( d=> { return {x:moment(d.date_time), y:d.Active+d.Failed, actualFailed:d.Failed,  type:"Failed"}})}
            >
              <VictoryArea interpolation="stepAfter"/>
              
            </VictoryGroup>
            <VictoryGroup
             data={this.state.data.map( d=> { return {x:moment(d.date_time), y:d.Active, type:"Active"}})}
            >
              <VictoryArea interpolation="stepAfter"/>
            </VictoryGroup>            
          </VictoryStack>
        </VictoryChart>
      </div>
      </Card>
    );
  }
}

