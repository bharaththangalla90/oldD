import React, { Component } from 'react';
import GoogleMapReact from 'google-map-react';
import { Popover, Modal, Button} from 'antd';
import { Table, Tag } from 'antd';
import supercluster from 'points-cluster';
import {VictoryPie} from 'victory';
import {MapMarkerIcon} from './MapIcons'

const getTag = status => {
  if(status === 'Active') return <Tag color="green">Active</Tag>
  if(status === 'Failed') return <Tag color="red">Inactive</Tag>
  else return <Tag color="gray">{status}</Tag>
}


export default class SimpleMap extends Component {
  static defaultProps = {
    center: {lat: 37.994402, lng:-91.760254},
    zoom: 4
  };

  state = {
    temp:[]
  }

  componentWillMount() {
    
  }

  
  render() {
    let clusterData = this.props.data.filter(clinic => clinic.data.net_location).map( (clinic,i) => { return {lat:clinic.data.net_location.lat, lng:clinic.data.net_location.lng, devices:clinic.data.data.map(d => { return {name:d.device_name, publicIP: deviceData(d).publicIp, status:deviceData(d).status}}), deviceCount:clinic.data.data.length, name:clinic.data.name, status:clinic.data.status}; } );
    //console.log(clusterData);
    let clusters = supercluster(clusterData, {
      minZoom: 0,
      maxZoom: 16,
      radius: 60,
    }) ({ bounds: { nw: { lat: 85, lng: -180 }, se: { lat: -85, lng: 180 } }, zoom: 4 })
    
    //console.log(clusters)

   const content =       
      <GoogleMapReact
        defaultCenter={this.props.center}
        defaultZoom={this.props.zoom}
        options={createMapOptions}
      >
        {
      clusters
        .map((d,i) => (
          d.numPoints === 1
            ? <MapIcon key={i} devices={d.points[0].devices} deviceCount={d.points[0].deviceCount} name={d.points[0].name} status={d.points[0].status} lat={d.points[0].lat} lng={d.points[0].lng} />
            : 
            <Popover content={<NetworksTable networks={d.points} />} title="Networks" lat={d.y} lng={d.x}>
            <div style={{width:"60px"}}><svg className="map-cluster-icon-shadow" width="100%" height="100%" viewBox="0 0 200 200">        
              <VictoryPie
              style={{      
                data: {
                  stroke: "#fff", strokeWidth: 7
                }
              }}
                standalone={false}
                width={200} height={200}                
                colorScale={["#1ABB9C", "#E74C3C"]}
                data={[{x:"Active", y:d.points.filter( p => p.status==='Active').length},{x:"Failed", y:d.points.filter( p => p.status==='Failed').length}]}
          labels={(d) => undefined}
              /> 
              <circle cx={100} cy={100} r={28} fill="#fff"/>
              <text x="87" y="115" style={{fontFamily: "Arial",
             fontSize: "45px",             
             fill: "#000"}}> {d.numPoints} </text>
            </svg>      </div>        
            </Popover>
        ))
    }
      </GoogleMapReact>
    ;
    return content;    
  }
}

const deviceData = d => {
  //console.log('debugging device data fn...')
  //console.log(d)
  return d[Object.keys(d).filter(k => k !== 'device_name')[0]][0]
}

const NetworksTable = (props) => {
  const columns = [{
  title: 'Name',
  dataIndex: 'name',
}, {
  title: 'Devices',
  dataIndex: 'deviceCount',
}, {
  title: 'Status',
  dataIndex: 'status',
  render: (text, record) => getTag(record.status)
}];

  return (
    <Table columns={columns} dataSource={props.networks} size="middle" pagination={false} />    
    )
}

const DevicesTable = (props) => {
  const columns = [{
  title: 'Device',
  dataIndex: 'name',
}, {
  title: 'Public IP',
  dataIndex: 'publicIP',
}, {
  title: 'Status',
  dataIndex: 'status',
}];

  return (
    <Table columns={columns} dataSource={props.devices} size="middle" pagination={false} />    
    )
}

class MapIcon extends React.Component {

  state= {
    modalVisible: false
  }

  showModal = () => {
    this.setState({
      modalVisible: true,
    });
  }

  handleOk = (e) => {
    //console.log(e);
    this.setState({
      modalVisible: false,
    });
  }
  handleCancel = (e) => {
    //console.log(e);
    this.setState({
      modalVisible: false,
    });
  }
 

  render() {
     return (
    <Popover content={<div>{this.props.deviceCount} {this.props.deviceCount > 1 ? "devices": "device"} <br /><br /><Button type="primary" onClick={this.showModal}>View Details</Button></div>} title={this.props.name} lat={28.994402} lng={-81.760254}>
    <Modal
          title={this.props.name}
          visible={this.state.modalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
        <DevicesTable devices={this.props.devices} />
          
        </Modal>
      <div>
      <MapMarkerIcon color={this.props.status==='Active' ? '#1ABB9C':'#E74C3C'} />
      </div>
      </Popover>
    )

  }
 
}

function createMapOptions(maps) {
  // next props are exposed at maps
  // "Animation", "ControlPosition", "MapTypeControlStyle", "MapTypeId",
  // "NavigationControlStyle", "ScaleControlStyle", "StrokePosition", "SymbolPath", "ZoomControlStyle",
  // "DirectionsStatus", "DirectionsTravelMode", "DirectionsUnitSystem", "DistanceMatrixStatus",
  // "DistanceMatrixElementStatus", "ElevationStatus", "GeocoderLocationType", "GeocoderStatus", "KmlLayerStatus",
  // "MaxZoomStatus", "StreetViewStatus", "TransitMode", "TransitRoutePreference", "TravelMode", "UnitSystem"
  return {
    zoomControlOptions: {
      position: maps.ControlPosition.RIGHT_CENTER,
      style: maps.ZoomControlStyle.SMALL
    },
    mapTypeControlOptions: {
      position: maps.ControlPosition.TOP_RIGHT
    },
    mapTypeControl: false,
    gestureHandling: 'greedy',
    styles: mapStyle,
    scrollwheel: false
  };
}

const mapStyle = [
    {
        "featureType": "administrative",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },    
    {
        "featureType": "administrative.country",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "on"
            }
        ]
    },
    {
        "featureType": "administrative.province",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative.locality",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "on"
            }
        ]
    },
    {
        "featureType": "administrative.neighborhood",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative.land_parcel",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "all",
        "stylers": [
            {
                "color": "#f2f2f2"
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "geometry",
        "stylers": [
            {
                "hue": "#ff0000"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "poi.attraction",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "road",
        "elementType": "all",
        "stylers": [
            {
                "saturation": -100
            },
            {
                "lightness": 45
            }
        ]
    },
    {
        "featureType": "road",
        "elementType": "geometry",
        "stylers": [
            {
                "visibility": "on"
            }
        ]
    },
    {
        "featureType": "road",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "simplified"
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "labels.icon",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "transit",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "all",
        "stylers": [
            {
                "color": "#46bcec"
            },
            {
                "visibility": "on"
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#49a9ea"
            }
        ]
    }
]

/*

{
          this.props.data.map( (clinic,i) => { if(clinic.data.net_location) return <MapIcon key={i} devices={clinic.data.data.map(d => { return {name:d.device_name, publicIP: deviceData(d).publicIp, status:deviceData(d).status}})} deviceCount={clinic.data.data.length} name={clinic.data.name} status={clinic.data.status} lat={clinic.data.net_location.lat} lng={clinic.data.net_location.lng} /> })
        }


<Avatar style={{ backgroundColor: "#2A3F54" }} lat={d.y} lng={d.x} size="small">{d.numPoints}</Avatar>
        */