import { Card, Table, Tag, Input, Modal, Form, Icon } from 'antd';
import React from 'react';

const Search = Input.Search;
const FormItem = Form.Item;
const confirm = Modal.confirm;

const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };

const getTag = status => {
  if(status === 'Active') return <Tag color="green">Active</Tag>
  if(status === 'Failed') return <Tag color="red">Inactive</Tag>
  else return <Tag color="gray">{status}</Tag>
}


const expandedRowRender = (clinic) => {
    console.log(clinic)
    const columns = [
      { title: 'Device', dataIndex: 'device_name' },
      { title: 'Status', dataIndex: 'status', render:(text, record) => getTag(record.status) },
    ];

    return (
      <Table
        columns={columns}
        dataSource={clinic.data.data? clinic.data.data.map(d => { return {device_name:d.device_name, publicIP: deviceData(d).publicIp, status:deviceData(d).status}}):[]}
        pagination={false}
      />
    );
  };


export default class ClinicSites extends React.Component {

  state = {
    clinicStatusData: [],
    searchString: ""
  }

  setSearchString = e => this.setState({searchString:e.target.value})

  componentWillMount() {
    const urls = ['http://10.195.77.27:5000/network_inactive_data', 'http://10.195.77.27:5000/network_active_data'];

    Promise.all(urls.map(url => fetch(url)))
    .then(responses =>
      Promise.all(responses.map(res => res.json())))
      .then(jsons => { this.setState({clinicStatusData:arrayize(Object.assign(jsons[0], jsons[1]))})})
  }

  editNetwork = (id) => {
    const data = this.state.clinicStatusData.filter(d => d.name === id)[0]
    this.setState({networkId: id, networkNameReadOnly: data['data']['name'], networkName: data['data']['name'], Tags: "", visible: true})
  }

  deleteNetwork = (id, name) => {
    const deleteMsg = 'Do you want to delete ' + name + ' network?'
    confirm({
    title: deleteMsg,
    onOk() {
      fetch(`http://10.195.77.27:5000/delete_network?net_id=${id}`,
      {
          headers: {
            'Content-Type': 'application/json'
          },
          method: "DELETE",
          body: {net_id: id}
      })
      .then(res => res.text())
      .then(data => alert(data))
      .catch(res => alert(res))
    },
    onCancel() {},
  });
  }

  handleOk = () => {
    this.setState({
      ModalText: '...',
      confirmLoading: true,
    });

    this.setState({confirmLoading:true}, () => {
      fetch(`http://10.195.77.27:5000/update_network?net_id=${this.state.networkId}`,
      {
          headers: {
            'Content-Type': 'application/json'
          },
          method: "POST",
          body: {net_id: this.state.networkId, name: this.state.networkName, tags: this.state.Tags}
      })
      .then(res => res.text())
      .then(data => this.setState({confirmLoading: false, visible: false}, () => alert(data)))
      .catch(res => this.setState({confirmLoading: false, visible: false}, () => alert(res)))
    })

  }
  handleCancel = () => {
    this.setState({
      visible: false,
    });
  }

  onUpdateNameField = (e) => {
    this.setState({networkName: e.target.value})
  }

  onUpdateTagField = (e) => {
    this.setState({Tags: e.target.value})
  }

  render() {

    const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      sorter: (a, b) => a.item.localeCompare(b.item),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      filters: [{
        text: 'Active',
        value: 'Active',
      }, {
        text: 'Failed',
        value: 'Failed',
      }],
      render: (text, record) => getTag(record.status),
      filterMultiple: true,
      onFilter: (value, record) => record.status.indexOf(value) === 0,
      sorter: (a, b) => a.status.localeCompare(b.status),
    },
    {
      title: 'Devices',
      dataIndex: 'devices',
      sorter: (a, b) => a.devices > b.devices
    },
    {
      title: 'Dashboard',
      render: (text, record) => <a target="_blank" rel="noopener noreferrer" href={"http://10.195.77.53/CiscoHealthCare/clinicdashboard?net_id=" + record.id + "&name=" + record.name}> Clinic Dashboard </a>
    },
    {
      title: 'Actions',
      render: (text, record) => <span><Icon type="edit" style={{fontSize: '14px'}} onClick={() => this.editNetwork(record.id)}></Icon>  <Icon type="delete" style={{fontSize: '14px'}} onClick={() => this.deleteNetwork(record.id, record.name)}></Icon></span>
    }
  ];

    const data = this.state.clinicStatusData.filter(d => d.data.name !== 'System-mgr-HC' && d.data.name.toLowerCase().indexOf(this.state.searchString) > -1).map( (d,i)=> {
      return {id: d.name, name:d.data.name, status: d.data.status, devices:d.data.data?d.data.data.length:0, key:i, data:d.data}
    })
    //this.state.clinicStatusData.length ? console.log(this.state.clinicStatusData): "";
    return <div><br/><Card title="Clinic Sites">
                 <Search
                  placeholder="search clinics"
                  style={{ width: 200 }}
                  value={this.state.searchString}
                  onChange={this.setSearchString}
                />
                <br />
                <br />
                <Table
                className="components-table-demo-nested"
                expandedRowRender={record=>expandedRowRender(record)}
                style={{backgroundColor:"#fff"}}
                columns={columns}
                dataSource={data}
                loading={this.state.clinicStatusData.length === 0}
                onChange={onChange} />
              </Card>
              <Modal title={this.state.networkNameReadOnly }
                visible={this.state.visible}
                onOk={this.handleOk}
                okText="Save"
                confirmLoading={this.state.confirmLoading}
                onCancel={this.handleCancel}
              >
                <FormItem {...formItemLayout} label="Network Name" >
                    <Input type="text" className="Form-control" placeholder="Enter Network Name" name="networkName" value={this.state.networkName} onChange={this.onUpdateNameField} />
                </FormItem>

                <FormItem {...formItemLayout} label="Tags" >
                     <Input type="text" className="Form-control" placeholder="Enter Tag" name="Tags" value={this.state.Tags} onChange={this.onUpdateTagField}/>
                </FormItem>
              </Modal>
            </div>
  }

}

const arrayize = o => {
  let res = [];
  for(let item in o) {
    res.push({name:item, data:o[item]});
  }
  return res;
}

function onChange(pagination, filters, sorter) {
  console.log('params', pagination, filters, sorter);
}

const deviceData = d => {
  //console.log('debugging device data fn...')
  //console.log(d)
  return d[Object.keys(d).filter(k => k !== 'device_name')[0]][0]
}
