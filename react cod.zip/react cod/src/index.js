import "babel-polyfill";
/*import "core-js/fn/symbol";
import 'core-js/es6/object';
import 'core-js/es6/map';
import 'core-js/es6/weak-map';*/

import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import './styles/index.css';

ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();
