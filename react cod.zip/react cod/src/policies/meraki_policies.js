import React from 'react'
import {Collapse, Row, Col, Table, Button, Modal, Form, Input, Select, message} from 'antd'

const FormItem = Form.Item;
const Option = Select.Option;
const Panel = Collapse.Panel;

let configData = []

const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 14 },
      },
    };

const getRadiusServerDetails = (index, data) => {
  return Object.keys(data[0]).map((item, i) => {return {key:item+i, property:item, value:data[0][item]}})
}

class ShowSSIDDetails extends React.Component {
  state = {}

  showModal = () => this.setState({modalVisible: true})
  handleOk = () => this.setState({modalVisible: false})
  handleCancel = () => this.setState({modalVisible: false})

  render() {
    const ssidDetails = Object.keys(this.props.data).map((d, i) => { return {key: i, property:d, value:(this.props.data[d] === null || typeof this.props.data[d] === 'object') ? "" : this.props.data[d] === false ? "No" : this.props.data[d] === true ? "Yes" : this.props.data[d], children: (typeof this.props.data[d] === 'object' && this.props.data[d] !== null) ? getRadiusServerDetails(i, this.props.data[d]) : null}})
    return (<span><a onClick={this.showModal}>View All</a>
      <Modal
          width={500}
          title= {this.props.data['name'] + " - Details"}
          visible={this.state.modalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
        <Table key={this.props.index} columns={[{title:"Property", dataIndex:"property", width: '50%'},{title:"Value", dataIndex:"value"}]} dataSource={ssidDetails} pagination={false} size="small" />
      </Modal>
      </span>
    )
  }
}

const expandedRowRender = (network) => {
  const columns = [
    { title: 'SSID', dataIndex: 'number' },
    { title: 'Name', dataIndex: 'name' },
    { title: 'Enabled', dataIndex: 'enabled', render: (text, record) => <p>{record.enabled ? "Yes" : "No"}</p>},
    { title: 'Auth Mode', dataIndex: 'authMode'},
    { title: 'IP Assignment', dataIndex: 'ipAssignmentMode'},
    { title: 'Admin Accessible', render: (text, record) => <p>{record.ssidAdminAccessible ? "Yes" : "No"}</p>},
    { title: 'Splash Page', render: (text, record) => <p>{record.splashPage === 'None' ? "No" : record.splashPage }</p>},
    { title: 'Action', render: (text, record) => <ShowSSIDDetails key={record.number} index={record.number} data={record} />}
  ];

    return (<Table key={network.key} className="networkssid" columns={columns} dataSource={network.data} pagination={false} />);
};

const getAllSSIDData = data => {
  return data[Object.keys(data).filter(d => d !== 'name')[0]]
}

const arrayize = (data) => {
  return data.map((d, i)=> {return {key: i, name: d.name, data: getAllSSIDData(d)}})
}

class MerakiSSID extends React.Component {
  state = {}

  componentWillMount() {
    fetch('http://10.195.77.27:5000/ssid_data')
      .then( response => response.json())
      .then( data => {this.setState({ssidData:arrayize(data)})})
  }

  render() {
    const columns = [
      { title: 'Network List', dataIndex: "name"}
    ];

    return <Table
      className="components-table-demo-nested"
      loading = {!this.state.ssidData}
      columns={columns} expandedRowRender={record=>expandedRowRender(record)}
      dataSource={this.state.ssidData}
      onChange={onChange} />
  }
}

class FirewallPolicy extends React.Component {
    state = {
        modalVisible: false
    }

    componentWillMount() {
      let res = []
      fetch('http://10.195.77.27:5000/l3_wfw_data')
        .then( response => response.json())
        .then( data => {
            let networkSSIDs = {}
            data.map((clinic => {
            let ssidList = []
            for(let clinicID in clinic) {
              clinic[clinicID].data.map((ssid => {
                for(let ssidItem in ssid) {
                  ssidList.push({id:ssidItem, name:"Unconfigured SSID-"+ ssidItem})
                  ssid[ssidItem].map((firewallRule => {
                    firewallRule.network = clinic[clinicID].network_name
                    firewallRule.ssid = "Unconfigured SSID-"+ ssidItem
                    res.push(firewallRule)
                  }))
                }
              }))
              networkSSIDs[clinicID] = {name:clinic[clinicID].network_name, ssid:ssidList}
            }

          }))
          this.setState({firewallRules: res, networkSSIDList: networkSSIDs})
        })
    }

    updatePolicyConfigs = (data) => {
      configData = data
    }

    saveFirewallRule = (e) => {
      fetch("http://10.195.77.27:5000/l3firewall?net_id=" + configData.network + "&ssidnum=" + configData.ssid,
      {
          method: "POST",
          body: [configData.policyConfig]
      })
      .then(res => res.text() )
      .then(data => message.success("Wireless firewall configuration updated successfully", 10))
      .catch(res => alert(res))

        this.setState({
          modalVisible: false,
        });
    }

    handleCancel = (e) => {
      this.setState({
        modalVisible: false,
      });
    }

    addFirewallRule() {
      this.setState({modalVisible: true});
    }

    render() {
      const networkName = Array.from(new Set(this.state.firewallRules.map(d=> d.network)))
      const networkFilter = networkName.map((d=> { return {text: d, value: d}}))

      const ssidName = Array.from(new Set(this.state.firewallRules.map(d=> d.ssid)))
      const ssidNameFilter = ssidName.map((d=> { return {text: d, value: d}}))

      const policy = Array.from(new Set(this.state.firewallRules.map(d=> d.policy)))
      const policyFilter = policy.map((d=> { return {text: d, value: d}}))

      const columns = [
      { title: 'Network', dataIndex: "network",
        filters: networkFilter,
        filterMultiple: true,
        onFilter: (value, record) => record.network.indexOf(value) === 0,
        sorter: (a, b) => a.network.localeCompare(b.network)
      },
      { title: 'SSID', dataIndex: 'ssid',
        filters: ssidNameFilter,
        filterMultiple: true,
        onFilter: (value, record) => record.ssid.indexOf(value) === 0,
        sorter: (a, b) => a.ssid.localeCompare(b.ssid)
      },
      { title: 'Policy', dataIndex: 'policy',
        filters: policyFilter,
        filterMultiple: true,
        onFilter: (value, record) => record.policy.indexOf(value) === 0,
        sorter: (a, b) => a.policy.localeCompare(b.policy)
      },
      { title: 'Destination IP', dataIndex: 'dst_cidr' },
      { title: 'Port', dataIndex: 'dst_port'},
      { title: 'Protocol', dataIndex: 'proto'},
      { title: 'Comment', dataIndex: 'comment'}
    ];
      return (<span>
        <Row>
          <Col style={{marginBottom:"5px"}} span={2} offset={22}><Button onClick={()=>this.setState({modalVisible: true})} type="primary">Add Rule</Button></Col>
          <Col span={24}><Table columns={columns} loading={!this.state.firewallRules} dataSource={this.state.firewallRules} onChange={onChange} /></Col>
        </Row>
        <Modal
          width={600}
          title="Add Firewall Rule"
          visible={this.state.modalVisible} okText="Save"
          onOk={this.saveFirewallRule}
          onCancel={this.handleCancel}
        >
          <AddFirewallPolicy networkSSIDList={this.state.networkSSIDList} sendToParent={this.updatePolicyConfigs}/>
        </Modal></span>
      )
    }
}

export class AddFirewallPolicy extends React.Component {
    state = {
        policyConfig : {
          policy: "allow",
          protocol: "tcp",
          destCidr: "",
          destPort: "",
          comment: ""
        }
    }

    getSSIDListByNetworkID = (networkID) => {
      let ssidOptions = []
      for (let item in this.props.networkSSIDList) {
            if (item === networkID) {
              ssidOptions = this.props.networkSSIDList[item].ssid.map((d=> {
                return (<Option key={d.id} value={d.id}>{d.name}</Option>)
              }))
            }
          }
          this.setState({ssid:this.props.networkSSIDList[networkID].ssid[0]["id"], ssidOptions: ssidOptions})
    }

    componentWillMount = () => {
      let networkOptions = []
      for (let item in this.props.networkSSIDList) {
        networkOptions.push(<Option key={item} value={item}>{this.props.networkSSIDList[item].name}</Option>)
      }
      this.getSSIDListByNetworkID(Object.keys(this.props.networkSSIDList)[0])
      this.setState({network: Object.keys(this.props.networkSSIDList)[0], networkOptions:networkOptions})
    }

    onUpdateFirewallPolicies = (field, value) => {
      let Object = this.state.policyConfig
      Object[field] = value
      this.setState({policyConfig: Object}, ()=> this.props.sendToParent(this.state))
    }

    onNetworkChange = (value) => {
      this.getSSIDListByNetworkID(value)
      this.setState({network: value}, ()=> this.props.sendToParent(this.state))
    }

    onSSIDChange = (value) => {
      this.setState({ssid: value}, ()=> this.props.sendToParent(this.state))
    }

    onFirewallPolicyChange = (value) => {
      this.onUpdateFirewallPolicies("policy", value)
    }

    onFirewallProtocolChange = (value) => {
      this.onUpdateFirewallPolicies("protocol", value)
    }

    onUpdateField = (e) => {
      this.onUpdateFirewallPolicies(e.target.name, e.target.value)
    }

    render() {

        return (<Form className="Form-control">
            <FormItem {...formItemLayout} label="Network Name" >
            <Select name="network" value={this.state.network} onChange={this.onNetworkChange}>
                {this.state.networkOptions}
           </Select>
            </FormItem>

            <FormItem {...formItemLayout} label="SSID" >
            <Select name="ssid" value={this.state.ssid} onChange={this.onSSIDChange}>
                {this.state.ssidOptions}
           </Select>
            </FormItem>

            <FormItem {...formItemLayout} label="Policy" >
            <Select name="policy" value={this.state.policyConfig.policy} onChange={this.onFirewallPolicyChange}>
                <Option value="allow">Allow</Option>
                <Option value="deny">Deny</Option>
           </Select>
            </FormItem>
            <FormItem {...formItemLayout} label="Destination IP" >
                <Input type="text" className="Form-control" placeholder="Enter Destination IP" name="destCidr" value={this.state.policyConfig.destCidr} onChange={this.onUpdateField} />
            </FormItem>
            <FormItem {...formItemLayout} label="Protocol" >
            <Select name="protocol" value={this.state.policyConfig.protocol} onChange={this.onFirewallProtocolChange}>
                <Option value="tcp">TCP</Option>
                <Option value="udp">UDP</Option>
                <Option value="icmp">ICMP</Option>
                <Option value="any">Any</Option>
           </Select>
            </FormItem>
            <FormItem {...formItemLayout} label="Port" >
                 <Input type="text" className="Form-control" placeholder="Enter Port" name="destPort" value={this.state.policyConfig.destPort} onChange={this.onUpdateField}/>
            </FormItem>
            <FormItem {...formItemLayout} label="Comments" >
                 <Input type="textarea" rows={4} className="Form-control" placeholder="Enter Comments" name="comment" value={this.state.policyConfig.comment} onChange={this.onUpdateField}/>
            </FormItem>
        </Form>)
    }
}

export class MerakiPolicyContainer extends React.Component {
  callback(key) {
    console.log(key);
  }

  render() {
      return (
        <Collapse bordered={false} accordion defaultActiveKey={['1']} onChange={this.callback}>
          <Panel header="SSID" key="1">
          <Row>
          <Col span={24}><MerakiSSID/></Col>
          </Row>
          </Panel>
          <Panel header="Wireless Layer 3 Firewall" key="2">
            <FirewallPolicy />
          </Panel>
          <Panel header="Group Policies" key="3">
            <p>Under development...</p>
          </Panel>
          <Panel header="Access Policies" key="4">
            <p>Under development...</p>
          </Panel>
        </Collapse>
      )
  }
}

function onChange(pagination, filters, sorter) {
  console.log('params', pagination, filters, sorter);
}


