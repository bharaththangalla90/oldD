import React from 'react'
import {Card, Tabs} from 'antd'
import {MerakiPolicyContainer} from './meraki_policies'

const TabPane = Tabs.TabPane;

export default class Policies extends React.Component {

    callback(key) {
      //console.log(key);
    }

    render() {
    return  (<div> <br /><Card title="Policy Configurations" noHovering={true}>
                <Tabs defaultActiveKey="1" onChange={this.callback}>
                    <TabPane tab="Meraki" key="1">
                        <MerakiPolicyContainer/>
                    </TabPane>
                    <TabPane tab="Umbrella" key="2" style={{minHeight:"200px"}}><span style={{minHeight:"300px"}}> Umbrella Policies...</span></TabPane>
                    <TabPane tab="CloudLock" key="3" style={{minHeight:"200px"}}><span style={{minHeight:"300px"}}> CloudLock Policies..</span></TabPane>
                </Tabs>
              </Card></div>)
    }
}

