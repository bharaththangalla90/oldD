"theme": {
  "primary-color": "#1DA57A",
}